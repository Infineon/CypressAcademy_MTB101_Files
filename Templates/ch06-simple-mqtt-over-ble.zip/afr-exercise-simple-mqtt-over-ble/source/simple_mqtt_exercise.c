/* The config header is always included first. */
#include "iot_config.h"

/* Standard includes. */
#include <stdbool.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include "aws_demo.h" /* For demoContext_t structure declaration */
#include "iot_network_manager_private.h"
#include "iot_init.h"

/* Set up logging for this demo. */
#include "iot_demo_logging.h"

/* Platform layer includes. */
#include "platform/iot_clock.h"
#include "platform/iot_threads.h"

/* MQTT include. */
#include "iot_mqtt.h"
#include "aws_clientcredential.h"

#define MQTT_DEMO_STACKSIZE    ( configMINIMAL_STACK_SIZE * 8 )
#define MQTT_DEMO_PRIORITY     ( tskIDLE_PRIORITY + 6 )

#define MQTT_TIMEOUT_MS                          ( 5000 )

/**
 * @brief The longest client identifier that an MQTT server must accept (as defined
 * by the MQTT 3.1.1 spec) is 23 characters. Add 1 to include the length of the NULL
 * terminator.
 */
#define CLIENT_IDENTIFIER_MAX_LENGTH             ( 24 )

/**
 * @brief The keep-alive interval used for this demo.
 *
 * An MQTT ping request will be sent periodically at this interval.
 */
#define KEEP_ALIVE_SECONDS                       ( 60 )

#define IOT_DEMO_MQTT_TOPIC_PREFIX           "iotdemo"

/**
 * @brief The Last Will and Testament topic name in this demo.
 *
 * The MQTT server will publish a message to this topic name if this client is
 * unexpectedly disconnected.
 */
#define WILL_TOPIC_NAME                          IOT_DEMO_MQTT_TOPIC_PREFIX "/will"

/**
 * @brief The length of #WILL_TOPIC_NAME.
 */
#define WILL_TOPIC_NAME_LENGTH                   ( ( uint16_t ) ( sizeof( WILL_TOPIC_NAME ) - 1 ) )

/**
 * @brief The message to publish to #WILL_TOPIC_NAME.
 */
#define WILL_MESSAGE                             "MQTT demo unexpectedly disconnected."

/**
 * @brief The length of #WILL_MESSAGE.
 */
#define WILL_MESSAGE_LENGTH                      ( ( size_t ) ( sizeof( WILL_MESSAGE ) - 1 ) )

/**
 * @brief The length of each topic filter.
 *
 * For convenience, all topic filters are the same length.
 */
#define TOPIC_FILTER_LENGTH                      ( ( uint16_t ) ( sizeof( IOT_DEMO_MQTT_TOPIC_PREFIX "/topic/1" ) - 1 ) )

/**
 * @brief The maximum number of times each PUBLISH in this demo will be retried.
 */
#define PUBLISH_RETRY_LIMIT                      ( 10 )

/**
 * @brief A PUBLISH message is retried if no response is received within this
 * time.
 */
#define PUBLISH_RETRY_MS                         ( 1000 )

static IotNetworkManagerSubscription_t subscription = NULL;

/* Semaphore used to wait for a network to be available. */
static IotSemaphore_t demoNetworkSemaphore;

/* Variable used to indicate the connected network. */
static uint32_t demoConnectedNetwork = AWSIOT_NETWORK_TYPE_NONE;

void run_mqtt_demo( void * pArgument);
int _run_mqtt_publish_subscribe(void);
static int _initialize( demoContext_t * pContext );
static void _cleanup( void );
static uint32_t _getConnectedNetworkForDemo( demoContext_t * pDemoContext );
static void _onNetworkStateChangeCallback( uint32_t network, AwsIotNetworkState_t state, void * pContext );

extern const IotMqttSerializer_t IotBleMqttSerializer;

/*-----------------------------------------------------------*/

const IotMqttSerializer_t * demoGetSimpleMqttSerializer( void )
{
    const IotMqttSerializer_t * ret = NULL;

    #if BLE_ENABLED
        if( demoConnectedNetwork == AWSIOT_NETWORK_TYPE_BLE )
        {
            ret = &IotBleMqttSerializer;
        }
    #endif

    return ret;
}


/*******************************************************************************
* Function Name: InitApplication
********************************************************************************
* Summary:
*  Initializes the tasks required to run the application.
*
*******************************************************************************/
void InitApplication(void) {

    /* These demos are shared with the C SDK and perform their own initialization and cleanup. */
    static demoContext_t mqttDemoContext =
    {
        .networkTypes                = AWSIOT_NETWORK_TYPE_BLE, 	//democonfigNETWORK_TYPES,
        //.demoFunction                = run_mqtt_demo,				// NOT USED
        .networkConnectedCallback    = NULL, 						//DEMO_networkConnectedCallback,
        .networkDisconnectedCallback = NULL, 					    //DEMO_networkDisconnectedCallback
    };

    /* Platform API for creating a task that'll clean up itself after the task function exits */
    Iot_CreateDetachedThread( run_mqtt_demo,
                              &mqttDemoContext,
							  MQTT_DEMO_PRIORITY,
							  MQTT_DEMO_STACKSIZE );
}

/* This function is the simpler version of runDemoTask() in /demos/demo_runner/iot_demo_freertos.c */
void run_mqtt_demo( void * pArgument) {

	/* Three steps.
	 * 1. Initialize
	 * 2. Run MQTT publish & subscribe
	 * 3. Clean up.
	 */
	demoContext_t * pContext = ( demoContext_t * ) pArgument;

	int status = _initialize(pContext);

	if( status == EXIT_SUCCESS ) {
		IotLogInfo( "Successfully initialized the demo. ");

		status = _run_mqtt_publish_subscribe();

		/* Log the demo status. */
		if( status == EXIT_SUCCESS )
		{
			IotLogInfo( "Demo completed successfully." );
		}
		else
		{
			IotLogError( "Error running demo." );
		}

		_cleanup();
	}
	else {
        IotLogError( "Failed to initialize the demo. exiting..." );
    }
}

/*
 * 1. IotMqtt_Init()
 * 2. IotMqtt_Connect()
 * 3. IotMqtt_Publish()
 * 4. IotMqtt_Disconnect()
 * 5. IotMqtt_Cleanup()
 */
int _run_mqtt_publish_subscribe(void) {

	int status = EXIT_SUCCESS;

    IotMqttError_t connectStatus = IOT_MQTT_STATUS_PENDING;
    IotMqttError_t publishStatus = IOT_MQTT_STATUS_PENDING;

    /* Handle of the MQTT connection used in this demo. */
    IotMqttConnection_t mqttConnection = IOT_MQTT_CONNECTION_INITIALIZER;
    IotMqttNetworkInfo_t networkInfo = IOT_MQTT_NETWORK_INFO_INITIALIZER;
	IotMqttConnectInfo_t connectInfo = IOT_MQTT_CONNECT_INFO_INITIALIZER;
	IotMqttPublishInfo_t willInfo = IOT_MQTT_PUBLISH_INFO_INITIALIZER;

	void * pNetworkServerInfo = AwsIotNetworkManager_GetConnectionParams( demoConnectedNetwork );
    void * pCredentials = AwsIotNetworkManager_GetCredentials( demoConnectedNetwork );
    const IotNetworkInterface_t * pNetworkInterface = AwsIotNetworkManager_GetNetworkInterface( demoConnectedNetwork );

	/* Set the members of the network info not set by the initializer. This
	 * struct provided information on the transport layer to the MQTT connection. */
	networkInfo.createNetworkConnection = true;
	networkInfo.u.setup.pNetworkServerInfo = pNetworkServerInfo;
	networkInfo.u.setup.pNetworkCredentialInfo = pCredentials;
	networkInfo.pNetworkInterface = pNetworkInterface;

    #if ( IOT_MQTT_ENABLE_SERIALIZER_OVERRIDES == 1 ) && defined( IOT_DEMO_MQTT_SERIALIZER )
        networkInfo.pMqttSerializer = IOT_DEMO_MQTT_SERIALIZER;
    #endif

	char clientIdentifierBuffer[ CLIENT_IDENTIFIER_MAX_LENGTH ] = clientcredentialIOT_THING_NAME;

	/* Set the members of the connection info not set by the initializer. */
	connectInfo.awsIotMqttMode = true;
	connectInfo.cleanSession = true;
	connectInfo.keepAliveSeconds = KEEP_ALIVE_SECONDS;
	connectInfo.pWillInfo = &willInfo;
	connectInfo.pClientIdentifier = clientIdentifierBuffer;
	connectInfo.clientIdentifierLength = ( uint16_t ) strlen( clientIdentifierBuffer );

	/* Set the members of the Last Will and Testament (LWT) message info. The
	 * MQTT server will publish the LWT message if this client disconnects
	 * unexpectedly. */
	willInfo.pTopicName = WILL_TOPIC_NAME;
	willInfo.topicNameLength = WILL_TOPIC_NAME_LENGTH;
	willInfo.pPayload = WILL_MESSAGE;
	willInfo.payloadLength = WILL_MESSAGE_LENGTH;

	IotMqttError_t mqttInitStatus = IotMqtt_Init();

	if(mqttInitStatus == IOT_MQTT_SUCCESS) {

		connectStatus = IotMqtt_Connect( &networkInfo,
										 &connectInfo,
										 MQTT_TIMEOUT_MS,
										 &mqttConnection );

		if(connectStatus == IOT_MQTT_SUCCESS) {

			IotMqttCallbackInfo_t publishComplete = IOT_MQTT_CALLBACK_INFO_INITIALIZER;
			IotMqttPublishInfo_t publishInfo = IOT_MQTT_PUBLISH_INFO_INITIALIZER;
			intptr_t publishCount = 1;

			/* The MQTT library should invoke this callback when a PUBLISH message
			 * is successfully transmitted. */
			publishComplete.function = NULL; //_operationCompleteCallback;

			/* Pass the PUBLISH number to the operation complete callback. */
			publishComplete.pCallbackContext = ( void * ) publishCount;

			char pPublishPayload[] = "Hello world 1!";

			/* Set the common members of the publish info. */
			publishInfo.qos = IOT_MQTT_QOS_1;
			publishInfo.topicNameLength = TOPIC_FILTER_LENGTH;
			publishInfo.pPayload = pPublishPayload;
			publishInfo.payloadLength = strlen(pPublishPayload);
			publishInfo.retryMs = PUBLISH_RETRY_MS;
			publishInfo.retryLimit = PUBLISH_RETRY_LIMIT;
			publishInfo.pTopicName = IOT_DEMO_MQTT_TOPIC_PREFIX "/topic/1";

			configPRINTF((" Before publish \r\n"));

			/* PUBLISH a message. This is an asynchronous function that notifies of
			 * completion through a callback. */
			publishStatus = IotMqtt_Publish( mqttConnection,
											 &publishInfo,
											 0,
											 &publishComplete,
											 NULL );

			configPRINTF((" After publish \r\n"));

			if( publishStatus != IOT_MQTT_STATUS_PENDING )
			{
				IotLogError( "MQTT PUBLISH %d returned error %s.",
							 ( int ) publishCount,
							 IotMqtt_strerror( publishStatus ) );
				status = EXIT_FAILURE;
			}

			/* Wait for sometime before cleaning up the resources */
			vTaskDelay(pdMS_TO_TICKS( 3000UL ));

			IotMqtt_Disconnect( mqttConnection, 0 );
		}
		else {
			IotLogError( "MQTT CONNECT returned error %s.",
							 IotMqtt_strerror( connectStatus ) );
			status = EXIT_FAILURE;
		}


		IotMqtt_Cleanup();
	}
	else {
		IotLogError( "MQTT INIT returned error %s.",
								 IotMqtt_strerror( mqttInitStatus ) );
		status = EXIT_FAILURE;
	}

	return status;

}

/* This function is exact copy of the same function in /demos/demo_runner/iot_demo_freertos.c */
static uint32_t _getConnectedNetworkForDemo( demoContext_t * pDemoContext )
{
    uint32_t ret = ( AwsIotNetworkManager_GetConnectedNetworks() & pDemoContext->networkTypes );

    if( ( ret & AWSIOT_NETWORK_TYPE_WIFI ) == AWSIOT_NETWORK_TYPE_WIFI )
    {
        ret = AWSIOT_NETWORK_TYPE_WIFI;
    }
    else if( ( ret & AWSIOT_NETWORK_TYPE_BLE ) == AWSIOT_NETWORK_TYPE_BLE )
    {
        ret = AWSIOT_NETWORK_TYPE_BLE;
    }
    else if( ( ret & AWSIOT_NETWORK_TYPE_ETH ) == AWSIOT_NETWORK_TYPE_ETH )
    {
        ret = AWSIOT_NETWORK_TYPE_ETH;
    }
    else
    {
        ret = AWSIOT_NETWORK_TYPE_NONE;
    }

    return ret;
}


/* This function is the simpler version of the same function in /demos/demo_runner/iot_demo_freertos.c */
static void _onNetworkStateChangeCallback( uint32_t network,
                                           AwsIotNetworkState_t state,
                                           void * pContext )
{
    if( ( state == eNetworkStateEnabled ) && ( demoConnectedNetwork == AWSIOT_NETWORK_TYPE_NONE ) )
    {
        demoConnectedNetwork = network;
        IotSemaphore_Post( &demoNetworkSemaphore );
    }
    else if( ( state == eNetworkStateDisabled ) && ( demoConnectedNetwork == network ) )
    {
    	/* Not implemented here to keep it simple */
    }
}


/* This function is an exact copy of the same function in /demos/demo_runner/iot_demo_freertos.c */

/**
 * @brief Initialize the common libraries, Mqtt library and network manager.
 *
 * @return `EXIT_SUCCESS` if all libraries were successfully initialized;
 * `EXIT_FAILURE` otherwise.
 */
static int _initialize( demoContext_t * pContext )
{
	/* 1. IotSdk_Iit()
	 * 2. AwsIotNetworkManager_Init()
	 * 3. AwsIotNetworkManager_SubscribeForStateChange()
	 * 4. AwsIotNetworkManager_EnableNetwork()
	 * 5. Wait for the configured network to be initialized
	 */

    int status = EXIT_SUCCESS;
    bool commonLibrariesInitialized = false;
    bool semaphoreCreated = false;

    /* Initialize common libraries required by network manager and demo. */
    if( IotSdk_Init() == true )
    {
        commonLibrariesInitialized = true;
    }
    else
    {
        IotLogInfo( "Failed to initialize the common library." );
        status = EXIT_FAILURE;
    }

    if( status == EXIT_SUCCESS )
    {
        if( AwsIotNetworkManager_Init() != pdTRUE )
        {
            IotLogError( "Failed to initialize network manager library." );
            status = EXIT_FAILURE;
        }
    }

    if( status == EXIT_SUCCESS )
    {
        /* Create semaphore to signal that a network is available for the demo. */
        if( IotSemaphore_Create( &demoNetworkSemaphore, 0, 1 ) != true )
        {
            IotLogError( "Failed to create semaphore to wait for a network connection." );
            status = EXIT_FAILURE;
        }
        else
        {
            semaphoreCreated = true;
        }
    }

    if( status == EXIT_SUCCESS )
    {
        /* Subscribe for network state change from Network Manager. */
        if( AwsIotNetworkManager_SubscribeForStateChange( pContext->networkTypes,
                                                          _onNetworkStateChangeCallback,
                                                          pContext,
                                                          &subscription ) != pdTRUE )
        {
            IotLogError( "Failed to subscribe network state change callback." );
            status = EXIT_FAILURE;
        }
    }

    /* Initialize all the  networks configured for the device. */
    if( status == EXIT_SUCCESS )
    {
        if( AwsIotNetworkManager_EnableNetwork( configENABLED_NETWORKS ) != configENABLED_NETWORKS )
        {
            IotLogError( "Failed to intialize all the networks configured for the device." );
            status = EXIT_FAILURE;
        }
    }

    if( status == EXIT_SUCCESS )
    {
        /* Wait for network configured for the demo to be initialized. */
        demoConnectedNetwork = _getConnectedNetworkForDemo( pContext );

        if( demoConnectedNetwork == AWSIOT_NETWORK_TYPE_NONE )
        {
            /* Network not yet initialized. Block for a network to be intialized. */
            IotLogInfo( "No networks connected for the demo. Waiting for a network connection. " );
            IotSemaphore_Wait( &demoNetworkSemaphore );
            demoConnectedNetwork = _getConnectedNetworkForDemo( pContext );
        }
    }

    if( status == EXIT_FAILURE )
    {
        if( semaphoreCreated == true )
        {
            IotSemaphore_Destroy( &demoNetworkSemaphore );
        }

        if( commonLibrariesInitialized == true )
        {
            IotSdk_Cleanup();
        }
    }

    return status;
}


/* This function is an exact copy of the same function in /demos/demo_runner/iot_demo_freertos.c */

/**
 * @brief Clean up the common libraries and the MQTT library.
 */
static void _cleanup( void )
{
    /* Remove network manager subscription */
    AwsIotNetworkManager_RemoveSubscription( subscription );
    IotSemaphore_Destroy( &demoNetworkSemaphore );
    IotSdk_Cleanup();
}
