/******************************************************************************
* File Name: wifi_scan_and_connect.c
*
* Description: This is the source code for Wi-Fi Scanner Project on PSoC 6
*
*******************************************************************************
* (c) 2019, Cypress Semiconductor Corporation. All rights reserved.
*******************************************************************************
* This software, including source code, documentation and related materials
* ("Software"), is owned by Cypress Semiconductor Corporation or one of its
* subsidiaries ("Cypress") and is protected by and subject to worldwide patent
* protection (United States and foreign), United States copyright laws and
* international treaty provisions. Therefore, you may use this Software only
* as provided in the license agreement accompanying the software package from
* which you obtained this Software ("EULA").
*
* If no EULA applies, Cypress hereby grants you a personal, non-exclusive,
* non-transferable license to copy, modify, and compile the Software source
* code solely for use in connection with Cypress's integrated circuit products.
* Any reproduction, modification, translation, compilation, or representation
* of this Software except as specified above is prohibited without the express
* written permission of Cypress.
*
* Disclaimer: THIS SOFTWARE IS PROVIDED AS-IS, WITH NO WARRANTY OF ANY KIND,
* EXPRESS OR IMPLIED, INCLUDING, BUT NOT LIMITED TO, NONINFRINGEMENT, IMPLIED
* WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE. Cypress
* reserves the right to make changes to the Software without notice. Cypress
* does not assume any liability arising out of the application or use of the
* Software or any product or circuit described in the Software. Cypress does
* not authorize its products for use in any products where a malfunction or
* failure of the Cypress product may reasonably be expected to result in
* significant property damage, injury or death ("High Risk Product"). By
* including Cypress's product in a High Risk Product, the manufacturer of such
* system or application assumes all risk of such use and in doing so agrees to
* indemnify Cypress against all liability.
*******************************************************************************/

#include "FreeRTOS.h"
#include "FreeRTOSConfig.h"
#include "aws_demo_config.h"
#include "task.h"
#include "iot_wifi.h"
#include "iot_threads.h"
#include <stdbool.h>
#include "platform/iot_network.h"


#ifdef CY_USE_LWIP
#include "tcpip.h"
#endif

/* AWS library includes. */
#include "iot_system_init.h"
#include "iot_logging_task.h"
#include "iot_wifi.h"

/* BSP & Abstraction inclues */
#include "cybsp.h"
#include "cy_retarget_io.h"
#include "cyabs_rtos.h"

/*******************************************************************************
* Macros
********************************************************************************/
#define APP_TASK_STACK_SIZE                 (configMINIMAL_STACK_SIZE * 8)
#define APP_TASK_PRIORITY                   tskIDLE_PRIORITY

/* Maximum number of Wi-Fi networks to scan */
#define SCAN_NETWORK_MAX_COUNT              (100u)

/* Number of times to scan before connecting to a Wi-Fi network */
#define SCAN_COUNT                          (3u)

/* Delay between successive scans */
#define WIFI_SCAN_LOOP_DELAY_MS             (pdMS_TO_TICKS( 5000u ))

/* Configure the network credentials of the Wi-Fi network. */
#define WIFI_SSID                    "CY-IOT-HOTSPOT"
#define WIFI_PASSWORD                "10tl@b123"
#define WIFI_SECURITY                eWiFiSecurityWPA2


/*******************************************************************************
* Global Variables
********************************************************************************/
/* Names used for printing the security type of a network */
const char *security_names[] =
{
    "Open",             /* Open - No Security. */
    "WEP",              /* WEP Security. */
    "WPA",              /* WPA Security. */
    "WPA2",             /* WPA2 Security. */
    "WPA2 Enterprise",  /* WPA2 Enterprise Security */
    "Unknown"           /* Unknown Security. */
};

/* Stores the Wi-Fi scan results */
static WIFIScanResult_t ScanResults[SCAN_NETWORK_MAX_COUNT];

void RunApplication(void * pArgument);


/*******************************************************************************
* Function Name: InitApplication
********************************************************************************
* Summary:
*  Initializes all the tasks, queues, and other resources required to run the
*  application.
*
*******************************************************************************/
void InitApplication(void)
{
    /* Set up the application task */
    Iot_CreateDetachedThread(RunApplication, NULL, APP_TASK_PRIORITY, APP_TASK_STACK_SIZE);
}


/*******************************************************************************
* Function Name: RunApplication
********************************************************************************
* Summary:
*  Scans and prints the Wi-Fi networks. This function runs as a FreeRTOS task.
*
* Parameters:
*  pArgument - pointer to the argument to this task.
* 
*******************************************************************************/
void RunApplication(void * pArgument)
{   
    WIFINetworkParams_t NetworkParams;
    WIFIReturnCode_t WiFiStatus;
    uint8_t ucTempIp[4] = { 0 };
    uint8_t scanCount = SCAN_COUNT;

    WiFiStatus = WIFI_On();
    printf( "\r\nStarting Wi-Fi Scan Task..." );
    
    if(WiFiStatus == eWiFiSuccess)
    {
        while(scanCount > 0)
        {
            memset( ScanResults, 0x00, sizeof(ScanResults));
            WiFiStatus = WIFI_Scan( ScanResults, SCAN_NETWORK_MAX_COUNT );
            if ( WiFiStatus == eWiFiSuccess)
            {
                int i;
                printf( "\r\n\r\nWi-Fi Scan Results: " );
                printf( "\r\n---------------------------------------------------------------------------------------------------" );
                printf( "\r\n  #     CH   RSSI         Security                 BSSID                SSID" );
                printf( "\r\n---------------------------------------------------------------------------------------------------\r\n" );
                for (i = 0; i < SCAN_NETWORK_MAX_COUNT; i++)
                {
                    if ((ScanResults[i].ucBSSID[0] == 0) && (ScanResults[i].ucBSSID[1] == 0) && (ScanResults[i].ucBSSID[2] == 0) &&
                        (ScanResults[i].ucBSSID[3] == 0) && (ScanResults[i].ucBSSID[4] == 0) && (ScanResults[i].ucBSSID[5] == 0) )
                    {
                        break;
                    }
                    printf( "[%3i]  %3d   %3d    (%d)%-20s  %02x.%02x.%02x.%02x.%02x.%02x    %-32s\r\n",
                            i, ScanResults[i].cChannel, ScanResults[i].cRSSI, ScanResults[i].xSecurity, security_names[ScanResults[i].xSecurity],
                            ScanResults[i].ucBSSID[0], ScanResults[i].ucBSSID[1], ScanResults[i].ucBSSID[2],
                            ScanResults[i].ucBSSID[3], ScanResults[i].ucBSSID[4], ScanResults[i].ucBSSID[5],
                            ScanResults[i].cSSID);
                }
                scanCount --;
            }
            vTaskDelay( WIFI_SCAN_LOOP_DELAY_MS  );
        }

        /* Setup parameters. */
        NetworkParams.pcSSID = WIFI_SSID;
        NetworkParams.ucSSIDLength = sizeof( WIFI_SSID ) - 1;
        NetworkParams.pcPassword = WIFI_PASSWORD;
        NetworkParams.ucPasswordLength = sizeof( WIFI_PASSWORD ) - 1;
        NetworkParams.xSecurity = WIFI_SECURITY;
        NetworkParams.cChannel = 0;

        printf( "\r\nWi-Fi Scan complete. Connecting to AP '%s'.\r\n", NetworkParams.pcSSID );

        WiFiStatus = WIFI_ConnectAP( &( NetworkParams ) );

        if( WiFiStatus == eWiFiSuccess )
        {
            printf( "\r\nWi-Fi Connected to AP '%s'.\r\n", NetworkParams.pcSSID );

            WiFiStatus = WIFI_GetIP( ucTempIp );

            if ( WiFiStatus == eWiFiSuccess )
            {
                printf( "\r\nIP Address acquired %d.%d.%d.%d\r\n",
                                ucTempIp[ 0 ], ucTempIp[ 1 ], ucTempIp[ 2 ], ucTempIp[ 3 ] );
            }
        }
        else
        {
            printf( "\r\nWi-Fi failed to connect to AP '%s'.\r\n", NetworkParams.pcSSID );
        }

        WiFiStatus = WIFI_Disconnect();

        if( WiFiStatus == eWiFiSuccess )
        {
            printf( "\r\nWi-Fi successfully disconnected from AP '%s'.\r\n", NetworkParams.pcSSID );
            WiFiStatus = WIFI_Off();            
        }
        else
        {
            printf( "\r\nWi-Fi failed to disconnect from AP '%s'.\r\n", NetworkParams.pcSSID );
        }
    }
    else
    {
        printf("\r\nWi-Fi ON returned error: 0x%x\r\n", WiFiStatus);
    }

}

/* [] END OF FILE */
