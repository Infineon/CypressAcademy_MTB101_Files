/******************************************************************************
* File Name: cy_tft_counter.c
*
* Description: This file contains display thread function and related resources
*
*******************************************************************************
* (c) 2019, Cypress Semiconductor Corporation. All rights reserved.
*******************************************************************************
* This software, including source code, documentation and related materials
* ("Software"), is owned by Cypress Semiconductor Corporation or one of its
* subsidiaries ("Cypress") and is protected by and subject to worldwide patent
* protection (United States and foreign), United States copyright laws and
* international treaty provisions. Therefore, you may use this Software only
* as provided in the license agreement accompanying the software package from
* which you obtained this Software ("EULA").
*
* If no EULA applies, Cypress hereby grants you a personal, non-exclusive,
* non-transferable license to copy, modify, and compile the Software source
* code solely for use in connection with Cypress's integrated circuit products.
* Any reproduction, modification, translation, compilation, or representation
* of this Software except as specified above is prohibited without the express
* written permission of Cypress.
*
* Disclaimer: THIS SOFTWARE IS PROVIDED AS-IS, WITH NO WARRANTY OF ANY KIND,
* EXPRESS OR IMPLIED, INCLUDING, BUT NOT LIMITED TO, NONINFRINGEMENT, IMPLIED
* WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE. Cypress
* reserves the right to make changes to the Software without notice. Cypress
* does not assume any liability arising out of the application or use of the
* Software or any product or circuit described in the Software. Cypress does
* not authorize its products for use in any products where a malfunction or
* failure of the Cypress product may reasonably be expected to result in
* significant property damage, injury or death ("High Risk Product"). By
* including Cypress's product in a High Risk Product, the manufacturer of such
* system or application assumes all risk of such use and in doing so agrees to
* indemnify Cypress against all liability.
*******************************************************************************/
#include "cycfg.h"
#include "GUI.h"
#include "FreeRTOS.h"
#include "task.h"
#include "semphr.h"
#include "timers.h"
#include "LCDConf.h"

/* Platform layer includes. */
#include "platform/iot_clock.h"
#include "platform/iot_threads.h"

/*******************************************************************************
* Defines
********************************************************************************/
#define MAX_COUNT  (40)

/*******************************************************************************
* Global Variables
********************************************************************************/
/* Semaphore to count MQTT subscription callback */
IotSemaphore_t callbackCountSemaphore;

/*******************************************************************************
* Function Name: displayThread
********************************************************************************
* Summary:
*  Thread to display the number of publish messages received on TFT shield.
*
* Parameters:
*  arg - Pointer to the argument for the thread passed while thread creation
*
* Return:
*  void
*******************************************************************************/
void displayThread(void* arg)
{
	/* Variable to store count */
	uint32_t count = 0;

	/* Create semaphore */
	IotSemaphore_Create( &callbackCountSemaphore, 0, MAX_COUNT );

	/* Initialize display, emWin internal data structures and variables */
	GUI_Init();

	/* Set font size for the text being displayed */
	GUI_SetFont(&GUI_Font32_1);

	while(1)
	{
		/* Wait for MQTT subscription callback to give a semaphore */
		IotSemaphore_Wait( &callbackCountSemaphore );

		/* Increment count value for every publish message received */
		count++;

		/* Align text to Horizontal and Vertical Center */
		GUI_SetTextAlign(GUI_TA_HCENTER | GUI_TA_VCENTER);

		/* Display the count value at center of the screen to three decimal places */
		GUI_DispDecAt(count, YSIZE_PHYS/2, XSIZE_PHYS/2, 3);
	}
}
