/*
 * Amazon FreeRTOS V201908.00
 * Copyright (C) 2019 Amazon.com, Inc. or its affiliates.  All Rights Reserved.
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy of
 * this software and associated documentation files (the "Software"), to deal in
 * the Software without restriction, including without limitation the rights to
 * use, copy, modify, merge, publish, distribute, sublicense, and/or sell copies of
 * the Software, and to permit persons to whom the Software is furnished to do so,
 * subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in all
 * copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, FITNESS
 * FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR
 * COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER
 * IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN
 * CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
 *
 * http://aws.amazon.com/freertos
 * http://www.FreeRTOS.org
 */

/**
 * @file https_shadow_get.c
 * @brief Provides HTTPS Get Shadow functionality.
 *
 * This program demonstrates how to GET Shadow documents using HTTPS.
 */

/* The config header is always included first. */
#include "iot_config.h"

/* Standard includes. */
#include <stdbool.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

/* Set up logging for this demo. */
#include "iot_demo_logging.h"

/* JSON utilities include. */
#include "iot_json_utils.h"

/* Amazon FreeRTOS includes. */
#include "iot_https_client.h"
#include "iot_https_utils.h"
#include "aws_demo_config.h"
#include "platform/iot_network.h"
#include "private/iot_error.h"
#include "iot_demo_https_common.h"
#include "platform/iot_clock.h"
#include "platform/iot_threads.h"
#include "private/iot_https_internal.h"

#include "cy_pdl.h"
#include "cyhal.h"
#include "cybsp.h"

#include "queue.h"
#include "FreeRTOS.h"

/**
 * @brief Format string representing a Shadow document with a "reported" state.
 *
 * Note the client token, which is required for all Shadow updates. The client
 * token must be unique at any given time, but may be reused once the update is
 * completed. For this demo, a timestamp is used for a client token.
 */
#define SHADOW_REPORTED_JSON    \
    "{"                         \
    "\"state\":{"               \
    "\"reported\":{"            \
    "\"buttonPressCount\":%5d" \
    "}"                         \
    "},"                        \
    "\"clientToken\":\"%06lu\"" \
    "}"

/**
 * @brief The expected size of #SHADOW_REPORTED_JSON.
 *
 * Because all the format specifiers in #SHADOW_REPORTED_JSON include a length,
 * its full size is known at compile-time.
 */
#define EXPECTED_REPORTED_JSON_SIZE    ( sizeof( SHADOW_REPORTED_JSON ) + 2 )

// Push button and LED pin definitions
#define BUTTON_PIN							(P0_4)
#define LED_PIN							    (P13_7)

/* Variable to store button press counts */
extern int32_t buttonPressCount;

/* Queue details */
#define MESSAGE_SIZE					(sizeof(buttonPressCount))
#define QUEUE_SIZE						(50)
extern QueueHandle_t msgQueue;

/* Shadow URL for the configured endpoint
 * refer https://docs.aws.amazon.com/iot/latest/developerguide/device-shadow-rest-api.html for details */
#define SHADOW_DEMO_HTTPS_URL "https://" clientcredentialMQTT_BROKER_ENDPOINT "/things/" clientcredentialIOT_THING_NAME "/shadow"

/* TLS port for HTTPS. */
#ifndef IOT_DEMO_HTTPS_PORT
    #define IOT_DEMO_HTTPS_PORT    ( ( uint16_t ) 8443 )
#endif

/* Size in bytes of the User Buffer used to store the internal connection context. The size presented here accounts for
 * storage of the internal connection context. The minimum size can be found in extern const unint32_t connectionUserBufferMinimumSize. */
#ifndef IOT_DEMO_HTTPS_CONN_BUFFER_SIZE
    #define IOT_DEMO_HTTPS_CONN_BUFFER_SIZE    ( 512 )
#endif

/* Size in bytes of the user buffer used to store the internal request context and HTTP request header lines.
 * The size presented here accounts for the storeage of the internal context, the first request line in the HTTP
 * formatted header and extra headers. The minimum size can be found in extern const uint32_t requestUserBufferMinimumSize. */
#ifndef IOT_DEMO_HTTPS_REQ_USER_BUFFER_SIZE
    #define IOT_DEMO_HTTPS_REQ_USER_BUFFER_SIZE    ( 512 )
#endif

/* Size in bytes of the user buffer used to store the internal response context and the HTTP response header lines.
 * The size presented here accounts for the storeage of the internal context, the first request line in the HTTP
 * formatted header and extra headers. The minimum can be found in responseUserBufferMinimumSize.
 * Keep in mind that if the headers from the response do not all fit into this buffer, then the rest of the headers
 * will be discarded. The minimum size can be found in extern const uint32_t responseUserBufferMinimumSize. */
#ifndef IOT_DEMO_HTTPS_RESP_USER_BUFFER_SIZE
    #define IOT_DEMO_HTTPS_RESP_USER_BUFFER_SIZE    ( 1024 )
#endif

/* Size in bytes of the buffer used to store the response body (parts of it). This should be greater than or equal to
 * the size of the file we want to download.*/
#ifndef IOT_DEMO_HTTPS_RESP_BODY_BUFFER_SIZE
    #define IOT_DEMO_HTTPS_RESP_BODY_BUFFER_SIZE    ( 512 )
#endif

/* Time to wait in milliseconds before retrying the HTTPS Connection. A connection is only attempted again if
 * IOT_HTTPS_CONNECTION_ERROR is returned from IotHttpsClient_Connect(). This indicates an error in the network
 * layer. To view logging for network errors update IOT_LOG_LEVEL_NETWORK to IOT_LOG_ERROR in iot_config.h */
#ifndef IOT_DEMO_HTTPS_CONNECTION_RETRY_WAIT_MS
    #define IOT_DEMO_HTTPS_CONNECTION_RETRY_WAIT_MS    ( ( uint32_t ) 3000 )
#endif

/* Number of times to retry the HTTPS connection. A connection is only attempted again if
 * IOT_HTTPS_CONNECTION_ERROR is returned from IotHttpsClient_Connect(). This indicates an error in the network
 * layer. To view logging for network errors update IOT_LOG_LEVEL_NETWORK to IOT_LOG_ERROR in iot_config.h */
#ifndef IOT_DEMO_HTTPS_CONNECTION_NUM_RETRY
    #define IOT_DEMO_HTTPS_CONNECTION_NUM_RETRY    ( ( uint32_t ) 3 )
#endif

/** @endcond */

/*-----------------------------------------------------------*/

/**
 * @brief Buffer used to store the internal connection context.
 */
extern uint8_t _pConnUserBuffer[ IOT_DEMO_HTTPS_CONN_BUFFER_SIZE ];

/**
 * @brief Buffer used to store the request context and the HTTP request header lines.
 */
extern uint8_t _pReqUserBuffer[ IOT_DEMO_HTTPS_REQ_USER_BUFFER_SIZE ];

/**
 * @brief Buffer used to store the response context and the HTTP response header lines.
 */
extern uint8_t _pRespUserBuffer[ IOT_DEMO_HTTPS_RESP_USER_BUFFER_SIZE ];

/**
 * @brief Buffer used to store parts of the response body.
 */
extern uint8_t _pRespBodyBuffer[ IOT_DEMO_HTTPS_RESP_BODY_BUFFER_SIZE ];

/* A buffer containing the update document. It has static duration to prevent
 * it from being placed on the call stack. */
extern uint8_t requestStateDoc[ EXPECTED_REPORTED_JSON_SIZE + 1 ];

/* HTTPS Client library return status. */
extern IotHttpsReturnCode_t httpsClientStatus;

/* Configurations for the HTTPS connection. */
extern IotHttpsConnectionInfo_t connConfig;
/* Handle identifying the HTTPS connection. */
extern IotHttpsConnectionHandle_t connHandle;
/* Configurations for the HTTPS request. */
extern IotHttpsRequestInfo_t reqConfig;
/* Configurations for the HTTPS response. */
extern IotHttpsResponseInfo_t respConfig;

/* Handle identifying the HTTP request. This is valid after the request has been initialized with
    * IotHttpsClient_InitializeRequest(). */
extern IotHttpsRequestHandle_t reqHandle;

/* Handle identifying the HTTP response. This is valid after the reponse has been received with
    * IotHttpsClient_SendSync(). */
extern IotHttpsResponseHandle_t respHandle;
/* Synchronous request specific configurations. */
extern IotHttpsSyncInfo_t reqSyncInfo;
/* Synchronous response specific configurations. */
extern IotHttpsSyncInfo_t respSyncInfo;

/* The location of the path within string SHADOW_DEMO_HTTPS_URL. */
extern const char * pPath;
/* The length of the path within string SHADOW_DEMO_HTTPS_URL. */
extern size_t pathLen;
/* The location of the address within string SHADOW_DEMO_HTTPS_URL. */
extern const char * pAddress;
/* The length of the address within string SHADOW_DEMO_HTTPS_URL. */
extern size_t addressLen;

/* The status of HTTP responses for each request. */
extern uint16_t respStatus;

/* The body length of HTTP responses for each request. */
extern uint32_t bodyLength;

/* The current index in the number of connection tries. */
extern uint32_t connIndex;

/*-----------------------------------------------------------*/
/**
 * @brief Get the Shadow document using HTTPS GET.
 *
 * @return `EXIT_SUCCESS` if the demo completes successfully; `EXIT_FAILURE` otherwise.
 */
int HttpsGetShadow ( void )
{
    IOT_FUNCTION_ENTRY( int, EXIT_SUCCESS );

    /* Set the configurations needed for a synchronous request. */
    reqSyncInfo.pBody = NULL; /* This is a GET request so there is no data in the body. */
    reqSyncInfo.bodyLen = 0;  /* Since there is not data in the body the length is 0. */

    /* Set the configurations needed for a synchronous response. */
    respSyncInfo.pBody = _pRespBodyBuffer;             /* This is a GET request so should configure a place to retreive the
                                                        * response body. */
    respSyncInfo.bodyLen = sizeof( _pRespBodyBuffer ); /* The length of the GET request's response body. This should be
                                                        * greater than or equal to the size of the file requested, for the
                                                        * best performance. */

    /* Set the request configurations. */
    reqConfig.pPath = pPath;

    /* The path is everything that is not the address. It also includes the query. So we get the strlen( pPath ) to
     * acquire everything following in SHADOW_DEMO_HTTPS_URL. */
    reqConfig.pathLen = strlen( pPath );
    reqConfig.pHost = pAddress;
    reqConfig.hostLen = addressLen;
    reqConfig.method = IOT_HTTPS_METHOD_GET;
    reqConfig.isNonPersistent = false;
    reqConfig.userBuffer.pBuffer = _pReqUserBuffer;
    reqConfig.userBuffer.bufferLen = sizeof( _pReqUserBuffer );
    reqConfig.isAsync = false;
    reqConfig.u.pSyncInfo = &reqSyncInfo;

    /* Set the response configurations. */
    respConfig.userBuffer.pBuffer = _pRespUserBuffer;
    respConfig.userBuffer.bufferLen = sizeof( _pRespUserBuffer );
    respConfig.pSyncInfo = &respSyncInfo;

    /* Re-initialize the request to reuse the request. If we do not reinitialize then data from the last response
     * associated with this request will linger. We reuse reqHandle because we are sending a new sequential
     * synchronous request. IotHttpsClient_InitializeRequest will create a new request from the reqConfig and return
     * a reqHandle that is ready to use as a NEW request. */
    httpsClientStatus = IotHttpsClient_InitializeRequest( &reqHandle, &reqConfig );

    if( httpsClientStatus != IOT_HTTPS_OK )
    {
        IotLogError( "An error occurred in IotHttpsClient_InitializeRequest() with error code: %d", httpsClientStatus );
        IOT_SET_AND_GOTO_CLEANUP( EXIT_FAILURE );
    }

    /* A new response handle is returned from IotHttpsClient_SendSync(). We reuse the respHandle variable because
        * the last response was already processed fully.  */

    httpsClientStatus = IotHttpsClient_SendSync( connHandle, reqHandle, &respHandle, &respConfig, 0 );

    /* If there was network error try again one more time. */
    if( httpsClientStatus == IOT_HTTPS_NETWORK_ERROR )
    {        
        /* Maybe the network error was because the server disconnected us. */
        httpsClientStatus = IotHttpsClient_Connect( &connHandle, &connConfig );

        if( httpsClientStatus != IOT_HTTPS_OK )
        {
            IotLogError( "Failed to reconnect to the endpoint URL after a network error on IotHttpsClient_SendSync(). Error code %d.", httpsClientStatus );
            IOT_SET_AND_GOTO_CLEANUP( EXIT_FAILURE );
        }
        
        httpsClientStatus = IotHttpsClient_SendSync( connHandle, reqHandle, &respHandle, &respConfig, 0 );

        if( httpsClientStatus != IOT_HTTPS_OK )
        {
            IotLogError( "Failed receiving the response on a second try after a network error. The error code is: %d", httpsClientStatus );
            IOT_SET_AND_GOTO_CLEANUP( EXIT_FAILURE );
        }
    }
    else if( httpsClientStatus != IOT_HTTPS_OK )
    {
        IotLogError( "There has been an error receiving the response. The error code is: %d", httpsClientStatus );
        IOT_SET_AND_GOTO_CLEANUP( EXIT_FAILURE );
    }

    httpsClientStatus = IotHttpsClient_ReadResponseStatus( respHandle, &respStatus );

    if( httpsClientStatus != IOT_HTTPS_OK )
    {
        IotLogError( "Error in retreiving the response status. Error code %d", httpsClientStatus );
        IOT_SET_AND_GOTO_CLEANUP( EXIT_FAILURE );
    }

    /* Update the length of shadow document received. */
    bodyLength = respHandle->pBodyCur - respHandle->pBody;

    IOT_FUNCTION_CLEANUP_BEGIN();

    /* Disconnect from the server even if the server may have already disconnected us. */
    if( connHandle != NULL && status == EXIT_FAILURE)
    {
        IotHttpsClient_Disconnect( connHandle );
    }

    IOT_FUNCTION_CLEANUP_END();
}

/*-----------------------------------------------------------*/

/**
 * @brief Parses a key in the "state" section of a Shadow document.
 *
 * @param[in] pDataDocument The Shadow document to parse.
 * @param[in] dataDocumentLength The length of `pDataDocument`.
 * @param[in] pDataKey The key in the shadow document to find. Must be NULL-terminated.
 * @param[out] pData Set to the first character in the data key.
 * @param[out] pDataLength The length of the data key.
 *
 * @return `true` if the given data key is found; `false` otherwise.
 */
bool _getJsonData( const char * pDataDocument,
                       size_t dataDocumentLength,
                       const char * pDataKey,
                       const char ** pData,
                       size_t * pDataLength )
{
    bool stateFound = false;
    const size_t keyLength = strlen( pDataKey );
    const char * pState = NULL;
    size_t stateLength = 0;

    /* Find the "state" key in the shadow document. */
    stateFound = IotJsonUtils_FindJsonValue( pDataDocument,
                                             dataDocumentLength,
                                             "state",
                                             5,
                                             &pState,
                                             &stateLength );

    if( stateFound == true )
    {        
        stateFound = false;
        /* Find the data key within the "state" section. */
        stateFound = IotJsonUtils_FindJsonValue( pState,
                                                 stateLength,
                                                 pDataKey,
                                                 keyLength,
                                                 pData,
                                                 pDataLength );
    }
    else
    {
        IotLogWarn( "Failed to find \"state\" in Shadow document." );
    }

    return stateFound;
}

/*-----------------------------------------------------------*/

/**
 * @brief Checks for already existing Shadow document from AWS IoT Core
 *
 * @param[in] thingNameLength The length of `pThingName`.
 *
 */
void _checkForShadowDocument( const char * const pThingName )
{
    /* Variables to store information about the change in Shadow state */
    bool fieldFound = false;
    char * pData = NULL;
    size_t dataLength = 0;
    buttonPressCount = 0;  

    IotLogInfo( "Fetching exiting Shadow document using HTTPS GET." );
    /* Get existing shadow document from the endpoint URL using HTTPS GET. */
    int status = HttpsGetShadow ();

    /* Check the status of the Shadow Get. */
    if( status != EXIT_SUCCESS )
    {
        IotLogError( "Failed to get Shadow document." );
        return;
    }  

    /* Find the "message" key in the shadow document. */
    fieldFound = IotJsonUtils_FindJsonValue( _pRespBodyBuffer,
                                             bodyLength,
                                             "message",
                                             sizeof("message") - 1,
                                             &pData,
                                             &dataLength );

    if (fieldFound)
    {
        if (strstr(pData, "No shadow exists with name") != NULL) 
        {
            IotLogInfo( "No pre-existing shadow document found for the Thing \"%s\"", pThingName);
            return;
        }
    }

    IotLogInfo( "Successfully retrieved the Shadow document." );   

    fieldFound = false;
    pData = NULL;
    dataLength = 0;
    
    /* Check if there is a different button press count state in the Shadow. */
    fieldFound = _getJsonData( _pRespBodyBuffer,
                            bodyLength,
                            "buttonPressCount",
                            &pData,
                            &dataLength );

    if( fieldFound == true )
    {
        /* Change the current count based on the value in the shadow document. */
        buttonPressCount = atoi(pData);
        IotLogInfo( "Updating Button Count to %d as per received Shadow document.",
                        buttonPressCount );

        /* Update the Request State Document for display of previous Shadow document in HttpsPostShadow() function. */
        snprintf( requestStateDoc,
                EXPECTED_REPORTED_JSON_SIZE + 1,
                SHADOW_REPORTED_JSON,
                ( int ) buttonPressCount,
                ( long unsigned ) ( IotClock_GetTimeMs() % 1000000 ) );
    }
}
