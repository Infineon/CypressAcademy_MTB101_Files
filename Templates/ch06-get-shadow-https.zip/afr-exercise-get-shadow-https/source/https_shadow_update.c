/*
 * Amazon FreeRTOS V201908.00
 * Copyright (C) 2019 Amazon.com, Inc. or its affiliates.  All Rights Reserved.
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy of
 * this software and associated documentation files (the "Software"), to deal in
 * the Software without restriction, including without limitation the rights to
 * use, copy, modify, merge, publish, distribute, sublicense, and/or sell copies of
 * the Software, and to permit persons to whom the Software is furnished to do so,
 * subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in all
 * copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, FITNESS
 * FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR
 * COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER
 * IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN
 * CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
 *
 * http://aws.amazon.com/freertos
 * http://www.FreeRTOS.org
 */

/**
 * @file https_shadow_update.c
 * @brief Demonstrates usage of the HTTPS library for Shadow update.
 *
 * This program demonstrates the using Shadow documents to update button presses using HTTPS.
 */

#include "https_shadow_include.h"
#include "iot_config.h"
#include "iot_wifi.h"
#include "aws_demo.h"
#include "platform/iot_clock.h"
#include "platform/iot_threads.h"
/*-----------------------------------------------------------*/

/* Declaration of demo function. */
int RunApplication( bool awsIotMqttMode,
                   const char * pIdentifier,
                   void * pNetworkServerInfo,
                   void * pNetworkCredentialInfo,
                   const IotNetworkInterface_t * pNetworkInterface );

/*******************************************************************************
* Function Name: InitApplication
********************************************************************************
* Summary:
*  Initializes the tasks required to run the application.
*
*******************************************************************************/
void InitApplication(void)
{
    static demoContext_t appContext =
    {
        .networkTypes                = AWSIOT_NETWORK_TYPE_WIFI,
        .demoFunction                = RunApplication,
        .networkConnectedCallback    = NULL,
        .networkDisconnectedCallback = NULL
    };

    Iot_CreateDetachedThread( runDemoTask,
                              &appContext,
                              tskIDLE_PRIORITY,
                              (configMINIMAL_STACK_SIZE * 8) );
}

/*-----------------------------------------------------------*/

/**
 * @brief The interrupt service routine for the Push button interrupt
 *
 * @param[in] callback_arg argument for the ISR.
 * @param[in] event Event that triggered the ISR.
 *
 */
void push_button_isr(void *callback_arg, cyhal_gpio_event_t event)
{
	( void )callback_arg; /* Suppress compiler warning */
    ( void )event; /* Suppress compiler warning */

    // Increment the button press counter
    buttonPressCount ++;

	BaseType_t xHigherPriorityTaskWoken = pdFALSE;

	if(0UL != ( CYHAL_GPIO_IRQ_FALL & event))
	{
        // Push the button press count to message queue
	    xQueueSendFromISR(msgQueue, (void *) &buttonPressCount, &xHigherPriorityTaskWoken); /* Push value onto queue*/
	}

    // Toggle LED1 to indicate button press
    cyhal_gpio_toggle(LED_PIN);

	portYIELD_FROM_ISR( xHigherPriorityTaskWoken );
}

/*-----------------------------------------------------------*/

/**
 * @brief Initialize the the HTTP client required for this demo.
 *
 * @return `EXIT_SUCCESS` if all libraries were successfully initialized;
 * `EXIT_FAILURE` otherwise.
 */
int _initializeDemo( void * pNetworkCredentialInfo,
                            const IotNetworkInterface_t * pNetworkInterface )
{
    IOT_FUNCTION_ENTRY( int, EXIT_SUCCESS );   

    IotLogInfo( "Shadow Update demo using HTTPS with the URL: %s", SHADOW_DEMO_HTTPS_URL );

    /* Retrieve the path location and length from SHADOW_DEMO_HTTPS_URL. */
    httpsClientStatus = IotHttpsClient_GetUrlPath( SHADOW_DEMO_HTTPS_URL,
                                                   ( size_t ) strlen( SHADOW_DEMO_HTTPS_URL ),
                                                   &pPath,
                                                   &pathLen );

    if( httpsClientStatus != IOT_HTTPS_OK )
    {
        IotLogError( "An error occurred in IotHttpsClient_GetUrlPath() on URL %s. Error code: %d",
                     SHADOW_DEMO_HTTPS_URL,
                     httpsClientStatus );
        IOT_SET_AND_GOTO_CLEANUP( EXIT_FAILURE );
    }

    /* Retrieve the address location and length from the SHADOW_DEMO_HTTPS_URL. */
    httpsClientStatus = IotHttpsClient_GetUrlAddress( SHADOW_DEMO_HTTPS_URL,
                                                      ( size_t ) strlen( SHADOW_DEMO_HTTPS_URL ),
                                                      &pAddress,
                                                      &addressLen );

    if( httpsClientStatus != IOT_HTTPS_OK )
    {
        IotLogError( "An error occurred in IotHttpsClient_GetUrlAddress() on URL %s\r\n. Error code %d",
                     SHADOW_DEMO_HTTPS_URL,
                     httpsClientStatus );
        IOT_SET_AND_GOTO_CLEANUP( EXIT_FAILURE );
    }

    /* Set the connection configurations. */
    connConfig.pAddress = pAddress;
    connConfig.addressLen = addressLen;
    connConfig.port = IOT_DEMO_HTTPS_PORT;
    connConfig.userBuffer.pBuffer = _pConnUserBuffer;
    connConfig.userBuffer.bufferLen = sizeof( _pConnUserBuffer );
    connConfig.pClientCert = ( ( IotNetworkCredentials_t * ) pNetworkCredentialInfo )->pClientCert;
    connConfig.clientCertLen = ( ( IotNetworkCredentials_t * ) pNetworkCredentialInfo )->clientCertSize;
    connConfig.pPrivateKey = ( ( IotNetworkCredentials_t * ) pNetworkCredentialInfo )->pPrivateKey;
    connConfig.privateKeyLen = ( ( IotNetworkCredentials_t * ) pNetworkCredentialInfo )->privateKeySize;
    connConfig.pNetworkInterface = pNetworkInterface;
    

    /* Initialize the HTTPS library. */
    httpsClientStatus = IotHttpsClient_Init();

    if( httpsClientStatus != IOT_HTTPS_OK )
    {
        IotLogError( "An error occurred initializing the HTTPS library. Error code: %d", httpsClientStatus );
        IOT_SET_AND_GOTO_CLEANUP( EXIT_FAILURE );
    }

    /* Connect to the AWS endpoint URL. */
    for( connIndex = 1; connIndex <= IOT_DEMO_HTTPS_CONNECTION_NUM_RETRY; connIndex++ )
    {
        IotLogInfo( "Connecting to the HTTP server at the endpoint URL.." );

        httpsClientStatus = IotHttpsClient_Connect( &connHandle, &connConfig );

        if( ( httpsClientStatus == IOT_HTTPS_CONNECTION_ERROR ) &&
            ( connIndex < IOT_DEMO_HTTPS_CONNECTION_NUM_RETRY ) )
        {
            IotLogError( "Failed to connect to the endpoint URL, retrying after %d ms.",
                         IOT_DEMO_HTTPS_CONNECTION_RETRY_WAIT_MS );
            IotClock_SleepMs( IOT_DEMO_HTTPS_CONNECTION_RETRY_WAIT_MS );
            continue;
        }
        else
        {
            break;
        }
    }

    if( httpsClientStatus != IOT_HTTPS_OK )
    {
        IotLogError( "Failed to connect to the endpoint URL. Error code: %d.", httpsClientStatus );
        IOT_SET_AND_GOTO_CLEANUP( EXIT_FAILURE );
    }

    IotLogInfo( "Successfully connected to the endpoint URL." );


    IOT_FUNCTION_CLEANUP_BEGIN();

    /* Disconnect from the server even if the server may have already disconnected us. */
    if( connHandle != NULL && status == EXIT_FAILURE)
    {
        IotHttpsClient_Disconnect( connHandle );
    }
    
    IOT_FUNCTION_CLEANUP_END();
}

/*-----------------------------------------------------------*/

/**
 * @brief Post the Shadow document using HTTP POST.
 *
 * @param[in] value The integer value that is to be updated in the Shadow document.
 *
 * @return `EXIT_SUCCESS` if the demo completes successfully; `EXIT_FAILURE` otherwise.
 */
int HttpsPostShadow ( int32_t value )
{
    IOT_FUNCTION_ENTRY( int, EXIT_SUCCESS );  

    int docLength = 0;  

    IotLogInfo( "Updating Shadow document." );

    if( strlen(requestStateDoc) > 0 )
    {
        IotLogInfo( "Previous: %s", requestStateDoc );
    }
    else
    {        
        IotLogWarn( "Previous state not found in Shadow updated document." );        
    }

    /* Generate a Shadow reported state document, using a timestamp for the client
        * token. To keep the client token within 6 characters, it is modded by 1000000. */
    docLength = snprintf( requestStateDoc,
                        EXPECTED_REPORTED_JSON_SIZE + 1,
                        SHADOW_REPORTED_JSON,
                        ( int ) value,
                        ( long unsigned ) ( IotClock_GetTimeMs() % 1000000 ) );

    /* Check for errors from snprintf. The expected value is the length of
        * the reported JSON document less the format specifier for the state. */
    if( ( size_t ) docLength != EXPECTED_REPORTED_JSON_SIZE)
    {
        IotLogError( "Failed to generate reported state document for Shadow update.." );

        IOT_SET_AND_GOTO_CLEANUP( EXIT_FAILURE );
    }    

    IotLogInfo( "Current : %s", requestStateDoc );

    /* Clearing the buffers before use. */
    memset( _pRespBodyBuffer, 0, sizeof( _pRespBodyBuffer ) );
    memset( _pReqUserBuffer, 0, sizeof( _pReqUserBuffer ) );
    memset( _pRespUserBuffer, 0, sizeof( _pRespUserBuffer ) );

    /* Set the configurations needed for a synchronous response. */
    respSyncInfo.pBody = _pRespBodyBuffer;            
    respSyncInfo.bodyLen = sizeof( _pRespBodyBuffer ); 

    /* Set the configurations needed for a synchronous request. */
    reqSyncInfo.pBody = requestStateDoc; /* This field contains the JSON data that we need to post 
                                            to the endpoint URL as a Shadow document */
    reqSyncInfo.bodyLen = EXPECTED_REPORTED_JSON_SIZE; 

    /* Set the request configurations. */
    reqConfig.pPath = pPath;
    
    /* The path is everything that is not the address. It also includes the query. So we get the strlen( pPath ) to
     * acquire everything following in SHADOW_DEMO_HTTPS_URL. */
    reqConfig.pathLen = strlen( pPath );
    reqConfig.pHost = pAddress;
    reqConfig.hostLen = addressLen;
    reqConfig.method = IOT_HTTPS_METHOD_POST; // This is an HTTP POST method.
    reqConfig.isNonPersistent = false;
    reqConfig.userBuffer.pBuffer = _pReqUserBuffer;
    reqConfig.userBuffer.bufferLen = sizeof( _pReqUserBuffer );
    reqConfig.isAsync = false;
    reqConfig.u.pSyncInfo = &reqSyncInfo;

    /* Set the response configurations. */
    respConfig.userBuffer.pBuffer = _pRespUserBuffer;
    respConfig.userBuffer.bufferLen = sizeof( _pRespUserBuffer );
    respConfig.pSyncInfo = &respSyncInfo;

    /* Re-initialize the request to reuse the request. If we do not reinitialize then data from the last response
     * associated with this request will linger. We reuse reqHandle because we are sending a new sequential
     * synchronous request. IotHttpsClient_InitializeRequest will create a new request from the reqConfig and return
     * a reqHandle that is ready to use as a NEW request. */
    httpsClientStatus = IotHttpsClient_InitializeRequest( &reqHandle, &reqConfig );

    if( httpsClientStatus != IOT_HTTPS_OK )
    {
        IotLogError( "An error occurred in IotHttpsClient_InitializeRequest() with error code: %d", httpsClientStatus );
        IOT_SET_AND_GOTO_CLEANUP( EXIT_FAILURE );
    }

    /* A new response handle is returned from IotHttpsClient_SendSync(). We reuse the respHandle variable because
        * the last response was already processed fully.  */

    httpsClientStatus = IotHttpsClient_SendSync( connHandle, reqHandle, &respHandle, &respConfig, 0 );

    /* If there was network error try again one more time. */
    if( httpsClientStatus == IOT_HTTPS_NETWORK_ERROR )
    {
        /* Maybe the network error was because the server disconnected us. */
        httpsClientStatus = IotHttpsClient_Connect( &connHandle, &connConfig );

        if( httpsClientStatus != IOT_HTTPS_OK )
        {
            IotLogError( "Failed to reconnect to the endpoint URL after a network error on IotHttpsClient_SendSync(). Error code %d.", httpsClientStatus );
            IOT_SET_AND_GOTO_CLEANUP( EXIT_FAILURE );
        }
        
        httpsClientStatus = IotHttpsClient_SendSync( connHandle, reqHandle, &respHandle, &respConfig, 0 );

        if( httpsClientStatus != IOT_HTTPS_OK )
        {
            IotLogError( "Failed receiving the response on a second try after a network error. The error code is: %d", httpsClientStatus );
            IOT_SET_AND_GOTO_CLEANUP( EXIT_FAILURE );
        }
    }
    else if( httpsClientStatus != IOT_HTTPS_OK )
    {
        IotLogError( "There has been an error receiving the response. The error code is: %d", httpsClientStatus );
        IOT_SET_AND_GOTO_CLEANUP( EXIT_FAILURE );
    }

    if( httpsClientStatus == IOT_HTTPS_OK && status == EXIT_SUCCESS)
    {
        IotLogInfo( "Successfully updated shadow document." );
    }

    
    IOT_FUNCTION_CLEANUP_BEGIN();

    /* Disconnect from the server even if the server may have already disconnected us. */
    if( connHandle != NULL && status == EXIT_FAILURE)
    {
        IotLogInfo( "Error occurred. Disconnecting from HTTP client.." );
        IotHttpsClient_Disconnect( connHandle );
    }

    IOT_FUNCTION_CLEANUP_END();
}

/*-----------------------------------------------------------*/

/**
 * @brief The function that runs the CY Https Shadow Update demo, called by the demo runner.
 *
 * @param[in] awsIotMqttMode Ignored for the Shadow demo.
 * @param[in] pIdentifier NULL-terminated Shadow Thing Name.
 * @param[in] pNetworkServerInfo Ignored for the Shadow demo.
 * @param[in] pNetworkCredentialInfo Passed to the HTTPS client connect function when
 * establishing the HTTPS connection for Shadows.
 * @param[in] pNetworkInterface The network interface to use for this demo.
 *
 * @return `EXIT_SUCCESS` if the demo completes successfully; `EXIT_FAILURE` otherwise.
 */
int RunApplication( bool awsIotMqttMode,
                    const char * pIdentifier,
                    void * pNetworkServerInfo,
                    void * pNetworkCredentialInfo,
                    const IotNetworkInterface_t * pNetworkInterface )
{
    int status = EXIT_SUCCESS;

    /* Length of Shadow Thing Name. */
    size_t thingNameLength = 0;    

    /* Pointer to receive message from the message queue */
    int32_t msg;

    /* Avoid compiler warnings. */
    ( void ) awsIotMqttMode;
    ( void ) pNetworkServerInfo;

    /* Determine the length of the Thing Name. */
    if( pIdentifier != NULL )
    {
        thingNameLength = strlen( pIdentifier );

        if( thingNameLength == 0 )
        {
            IotLogError( "The length of the Thing Name (identifier) must be nonzero." );

            status = EXIT_FAILURE;
        }
    }
    else
    {
        IotLogError( "A Thing Name (identifier) must be provided for the Shadow demo." );

        status = EXIT_FAILURE;
    }

    /* Initialize the HTTP client required for this demo. */
    if( status == EXIT_SUCCESS )
    {
        status = _initializeDemo(pNetworkCredentialInfo, pNetworkInterface);
    }

    if ( status == EXIT_SUCCESS )
    {
        /* Reset the button press counter to zero. */
        buttonPressCount = 0;

        /* Set the Shadow callbacks for this demo. */
        _checkForShadowDocument( pIdentifier );

        /* Create a message queue to update button press count to the Shadow document */
        msgQueue = xQueueCreate( QUEUE_SIZE, sizeof(buttonPressCount));

        /* Configure and setup interrupt for the button */
        cyhal_gpio_init(BUTTON_PIN, CYHAL_GPIO_DIR_INPUT, CYHAL_GPIO_DRIVE_PULLUP, 1);
        cyhal_gpio_register_callback(BUTTON_PIN, push_button_isr, NULL);
        cyhal_gpio_enable_event(BUTTON_PIN, CYHAL_GPIO_IRQ_FALL, 3, true);

        /* Configure the LED */
        cyhal_gpio_init(LED_PIN, CYHAL_GPIO_DIR_OUTPUT, CYHAL_GPIO_DRIVE_STRONG, 1);

        IotLogInfo( "Press SW2 to update button press count in the shadow document." );

        while ( 1 )
        {
            /* Wait until a publish is requested */
            xQueueReceive(msgQueue, &msg, portMAX_DELAY);

            IotLogInfo("Button Pressed !! Count =  %d.", msg);

            /* Send Shadow updates via HTTPS. */
            status = HttpsPostShadow(msg);            

            /* Check the status of the Shadow update. */
            if( status != EXIT_SUCCESS )
            {
                IotLogError( "Failed to send Shadow update." );
            }                        
            
            /* Wait 100 milliseconds */
            vTaskDelay(100);
        }
    }    

    /* Disconnect from the server even if the server may have already disconnected us. */
    if( connHandle != NULL )
    {
        IotHttpsClient_Disconnect( connHandle );
    }

    return status;
}
