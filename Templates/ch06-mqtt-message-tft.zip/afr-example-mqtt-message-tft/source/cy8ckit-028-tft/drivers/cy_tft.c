/***************************************************************************//**
* \file cy_tft.c
* \version 1.0
*
* \brief
*    This is display software i8080 interface source file
*
********************************************************************************
* \copyright
* Copyright 2018-2019 Cypress Semiconductor Corporation
* SPDX-License-Identifier: Apache-2.0
*
* Licensed under the Apache License, Version 2.0 (the "License");
* you may not use this file except in compliance with the License.
* You may obtain a copy of the License at
*
*     http://www.apache.org/licenses/LICENSE-2.0
*
* Unless required by applicable law or agreed to in writing, software
* distributed under the License is distributed on an "AS IS" BASIS,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the License for the specific language governing permissions and
* limitations under the License.
*******************************************************************************/


#include "cy_tft.h"
#include "cyhal.h"

#ifndef CY8CKIT_028_TFT_CUSTOM_CONFIG
    #include "cy8ckit_028_tft_config.h"
#endif

/*******************************************************************************
* Function Name: write_data
****************************************************************************//**
*
* \brief
*   Writes one byte of data to the software i8080 interface.
*
* \details
*   This function:
*       - Writes data to the data bus
*       - Sends low pulse to the LCD_NWR line to write data
*
*******************************************************************************/
__STATIC_INLINE void write_data(uint8_t data)
{
	cyhal_gpio_write(CY_TFT_DB8,  data     & 0x01);
	cyhal_gpio_write(CY_TFT_DB9, (data>>1) & 0x01);
	cyhal_gpio_write(CY_TFT_DB10, (data>>2) & 0x01);
	cyhal_gpio_write(CY_TFT_DB11, (data>>3) & 0x01);
	cyhal_gpio_write(CY_TFT_DB12, (data>>4) & 0x01);
	cyhal_gpio_write(CY_TFT_DB13, (data>>5) & 0x01);
	cyhal_gpio_write(CY_TFT_DB14, (data>>6) & 0x01);
	cyhal_gpio_write(CY_TFT_DB15, (data>>7) & 0x01);

	cyhal_gpio_write(CY_TFT_NWR, 0u);
	cyhal_gpio_write(CY_TFT_NWR, 1u);
}


/*******************************************************************************
* Function Name: data_io_set_input(void)
****************************************************************************//**
*
* \brief
*   Changes data bus GPIO pins drive mode to digital Hi-Z with enabled input
*   buffer.
*
*******************************************************************************/
__STATIC_INLINE void data_io_set_input(void)
{
    /* enable input */
	cyhal_gpio_configure(CY_TFT_DB8, CYHAL_GPIO_DIR_INPUT, CYHAL_GPIO_DRIVE_NONE);
	cyhal_gpio_configure(CY_TFT_DB9, CYHAL_GPIO_DIR_INPUT, CYHAL_GPIO_DRIVE_NONE);
    cyhal_gpio_configure(CY_TFT_DB10, CYHAL_GPIO_DIR_INPUT, CYHAL_GPIO_DRIVE_NONE);
    cyhal_gpio_configure(CY_TFT_DB11, CYHAL_GPIO_DIR_INPUT, CYHAL_GPIO_DRIVE_NONE);
    cyhal_gpio_configure(CY_TFT_DB12, CYHAL_GPIO_DIR_INPUT, CYHAL_GPIO_DRIVE_NONE);
    cyhal_gpio_configure(CY_TFT_DB13, CYHAL_GPIO_DIR_INPUT, CYHAL_GPIO_DRIVE_NONE);
    cyhal_gpio_configure(CY_TFT_DB14, CYHAL_GPIO_DIR_INPUT, CYHAL_GPIO_DRIVE_NONE);
    cyhal_gpio_configure(CY_TFT_DB15, CYHAL_GPIO_DIR_INPUT, CYHAL_GPIO_DRIVE_NONE);
}


/*******************************************************************************
* Function Name: data_io_set_output(void)
****************************************************************************//**
*
* \brief
*   Changes data bus GPIO pins drive mode to strong drive with disabled input
*   buffer.
*
*******************************************************************************/
__STATIC_INLINE void data_io_set_output(void)
{
    /* enable output */
	cyhal_gpio_configure(CY_TFT_DB8, CYHAL_GPIO_DIR_OUTPUT, CYHAL_GPIO_DRIVE_STRONG);
	cyhal_gpio_configure(CY_TFT_DB9, CYHAL_GPIO_DIR_OUTPUT, CYHAL_GPIO_DRIVE_STRONG);
    cyhal_gpio_configure(CY_TFT_DB10, CYHAL_GPIO_DIR_OUTPUT, CYHAL_GPIO_DRIVE_STRONG);
    cyhal_gpio_configure(CY_TFT_DB11, CYHAL_GPIO_DIR_OUTPUT, CYHAL_GPIO_DRIVE_STRONG);
    cyhal_gpio_configure(CY_TFT_DB12, CYHAL_GPIO_DIR_OUTPUT, CYHAL_GPIO_DRIVE_STRONG);
    cyhal_gpio_configure(CY_TFT_DB13, CYHAL_GPIO_DIR_OUTPUT, CYHAL_GPIO_DRIVE_STRONG);
    cyhal_gpio_configure(CY_TFT_DB14, CYHAL_GPIO_DIR_OUTPUT, CYHAL_GPIO_DRIVE_STRONG);
    cyhal_gpio_configure(CY_TFT_DB15, CYHAL_GPIO_DIR_OUTPUT, CYHAL_GPIO_DRIVE_STRONG);
}


/*******************************************************************************
* Function Name: read_data
****************************************************************************//**
*
* \brief
*   Reads one byte of data from the software i8080 interface.
*
* \details
*   This function:
*       - Sets low level on LCD_NRD line
*       - Reads data from the data bus
*       - Sets high level on LCD_NRD line
*
*******************************************************************************/
__STATIC_INLINE uint8_t read_data(void)
{
    uint8_t data = 0u;

    cyhal_gpio_write(CY_TFT_NRD, 0u);

    data |= cyhal_gpio_read(CY_TFT_DB8);
    data |= cyhal_gpio_read(CY_TFT_DB9)<<1;
    data |= cyhal_gpio_read(CY_TFT_DB10)<<2;
    data |= cyhal_gpio_read(CY_TFT_DB11)<<3;
    data |= cyhal_gpio_read(CY_TFT_DB12)<<4;
    data |= cyhal_gpio_read(CY_TFT_DB13)<<5;
    data |= cyhal_gpio_read(CY_TFT_DB14)<<6;
    data |= cyhal_gpio_read(CY_TFT_DB15)<<7;

    cyhal_gpio_write(CY_TFT_NRD, 1u);

    return data;
}


/*******************************************************************************
* Function Name: cy_tft_write_reset_pin(uint8_t value)
****************************************************************************//**
*
* \brief
*   Sets value of the display Reset pin.
*
*******************************************************************************/
void cy_tft_write_reset_pin(uint8_t value)
{
	cyhal_gpio_write(CY_TFT_RST, value);
}


/*******************************************************************************
* Function Name: cy_tft_io_init(void)
****************************************************************************//**
*
* \brief
*   Initializes software i8080 interface.
*
* \details
*   This function:
*       - Initializes interface GPIO pins
*       TODO: add status return
*
*******************************************************************************/
void cy_tft_io_init(void)
{
	cyhal_gpio_init(CY_TFT_DB8, CYHAL_GPIO_DIR_OUTPUT, CYHAL_GPIO_DRIVE_STRONG, 0u);
	cyhal_gpio_init(CY_TFT_DB9, CYHAL_GPIO_DIR_OUTPUT, CYHAL_GPIO_DRIVE_STRONG, 0u);
	cyhal_gpio_init(CY_TFT_DB10, CYHAL_GPIO_DIR_OUTPUT, CYHAL_GPIO_DRIVE_STRONG, 0u);
	cyhal_gpio_init(CY_TFT_DB11, CYHAL_GPIO_DIR_OUTPUT, CYHAL_GPIO_DRIVE_STRONG, 0u);
	cyhal_gpio_init(CY_TFT_DB12, CYHAL_GPIO_DIR_OUTPUT, CYHAL_GPIO_DRIVE_STRONG, 0u);
	cyhal_gpio_init(CY_TFT_DB13, CYHAL_GPIO_DIR_OUTPUT, CYHAL_GPIO_DRIVE_STRONG, 0u);
	cyhal_gpio_init(CY_TFT_DB14, CYHAL_GPIO_DIR_OUTPUT, CYHAL_GPIO_DRIVE_STRONG, 0u);
	cyhal_gpio_init(CY_TFT_DB15, CYHAL_GPIO_DIR_OUTPUT, CYHAL_GPIO_DRIVE_STRONG, 0u);
	cyhal_gpio_init(CY_TFT_NWR, CYHAL_GPIO_DIR_OUTPUT, CYHAL_GPIO_DRIVE_STRONG, 1u);
	cyhal_gpio_init(CY_TFT_DC, CYHAL_GPIO_DIR_OUTPUT, CYHAL_GPIO_DRIVE_STRONG, 0u);
	cyhal_gpio_init(CY_TFT_RST, CYHAL_GPIO_DIR_OUTPUT, CYHAL_GPIO_DRIVE_STRONG, 1u);
	cyhal_gpio_init(CY_TFT_NRD, CYHAL_GPIO_DIR_OUTPUT, CYHAL_GPIO_DRIVE_STRONG, 1u);
}


/*******************************************************************************
* Function Name: cy_tft_write_command(uint8_t data)
****************************************************************************//**
*
* \brief
*   Writes one byte of data to the software i8080 interface with the LCD_DC pin 
*   set to 0
*
* \details
*   This function:
*       - Sets LCD_DC pin to 0
*       - Writes one data byte
*
*******************************************************************************/
void cy_tft_write_command(uint8_t data)
{
	cyhal_gpio_write(CY_TFT_DC, 0u);
    write_data(data);
}


/*******************************************************************************
* Function Name: cy_tft_write_data(uint8_t data)
****************************************************************************//**
*
* \brief
*   Writes one byte of data to the software i8080 interface with the LCD_DC pin 
*   set to 1
*
* \details
*   This function:
*       - Sets LCD_DC pin to 1
*       - Writes one data byte
*
*******************************************************************************/
void cy_tft_write_data(uint8_t data)
{
	cyhal_gpio_write(CY_TFT_DC, 1u);
    write_data(data);
}


/*******************************************************************************
* Function Name: cy_tft_write_command_stream(uint8_t data[], int num)
****************************************************************************//**
*
* \brief
*   Writes multiple bytes of data to the software i8080 interface with the LCD_DC
*   pin set to 0
*
* \details
*   This function:
*       - Sets LCD_DC pin to 0
*       - Writes data bytes
*
*******************************************************************************/
void cy_tft_write_command_stream(uint8_t data[], int num)
{
    int i = 0;

    cyhal_gpio_write(CY_TFT_DC, 0u);

    for(i = 0; i < num; i++)
    {
        write_data(data[i]);
    }
}


/*******************************************************************************
* Function Name: cy_tft_write_data_stream(uint8_t data[], int num)
****************************************************************************//**
*
* \brief
*   Writes multiple bytes of data to the software i8080 interface with the LCD_DC 
*   pin set to 1
*
* \details
*   This function:
*       - Sets LCD_DC pin to 1
*       - Writes data bytes
*
*******************************************************************************/
void cy_tft_write_data_stream(uint8_t data[], int num)
{
    int i = 0;

    cyhal_gpio_write(CY_TFT_DC, 1u);

    for(i = 0; i < num; i++)
    {
        write_data(data[i]);
    }
}


/*******************************************************************************
* Function Name: cy_tft_read_data(void)
****************************************************************************//**
*
* \brief
*   Reads one byte of data from the software i8080 interface with the LCD_DC pin 
*   set to 1
*
* \details
*   This function:
*       - Sets LCD_DC pin to 1
*       - Reads one data byte
*
*******************************************************************************/
uint8_t cy_tft_read_data(void)
{
	uint8_t data;

	cyhal_gpio_write(CY_TFT_DC, 1u);

    data_io_set_input();
    data = read_data();
    data_io_set_output();

    return data;
}


/*******************************************************************************
* Function Name: cy_tft_read_data_stream(uint8_t data[], int num)
****************************************************************************//**
*
* \brief
*   Reads multiple bytes of data from the software i8080 interface with the LCD_DC 
*   pin set to 1
*
* \details
*   This function:
*       - Sets LCD_DC pin to 1
*       - Reads data bytes
*
*******************************************************************************/
void cy_tft_read_data_stream(uint8_t data[], int num)
{
    int i = 0;

    cyhal_gpio_write(CY_TFT_DC, 1u);

    data_io_set_input();

    for(i = 0; i < num; i++)
    {
        data[i] = read_data();
    }

    data_io_set_output();
}


/* [] END OF FILE */

