/***************************************************************************//**
* \file cy8ckit_028_tft_config.h
* \version 1.0
*
* \brief
*    Configuration file of the shield support package.
*
********************************************************************************
* \copyright
* Copyright 2018-2019 Cypress Semiconductor Corporation
* SPDX-License-Identifier: Apache-2.0
*
* Licensed under the Apache License, Version 2.0 (the "License");
* you may not use this file except in compliance with the License.
* You may obtain a copy of the License at
*
*     http://www.apache.org/licenses/LICENSE-2.0
*
* Unless required by applicable law or agreed to in writing, software
* distributed under the License is distributed on an "AS IS" BASIS,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the License for the specific language governing permissions and
* limitations under the License.
*******************************************************************************/


#ifndef CY8CKIT_028_TFT_CONFIG_H_
#define CY8CKIT_028_TFT_CONFIG_H_

#include "cybsp.h"

/* Display connections */
#define CY_TFT_DB8          P9_0
#define CY_TFT_DB9          P9_1
#define CY_TFT_DB10         P9_2
#define CY_TFT_DB11         P9_4
#define CY_TFT_DB12         P9_5
#define CY_TFT_DB13         P0_2
#define CY_TFT_DB14         P13_0
#define CY_TFT_DB15         P13_1
#define CY_TFT_NWR     		P12_0
#define CY_TFT_DC      		P12_1
#define CY_TFT_RST     		P12_2
#define CY_TFT_NRD     		P12_3

/* Internal measurement unit (IMU) : accelerometer + gyro */
#define CY_IMU_I2C_SCL      CYBSP_I2C_SCL
#define CY_IMU_I2C_SDA      CYBSP_I2C_SDA
#define CY_IMU_INT_1        CYBSP_A2
#define CY_IMU_INT_2        CYBSP_A3

/* Ambient light sensor */
#define CY_ALS_OUT          CYBSP_A0

/* PDM Microphone */
#define CY_PDM_CLK          CYBSP_A4
#define CY_PDM_DATA         CYBSP_A5

/* Audio Codec */
#define CY_CODEC_I2C_SCL    CYBSP_I2C_SCL
#define CY_CODEC_I2C_SDA    CYBSP_I2C_SDA
#define CY_CODEC_I2S_MCLK   CYBSP_D0
#define CY_CODEC_I2S_TX_SCK CYBSP_D1
#define CY_CODEC_I2S_TX_WS  CYBSP_D2
#define CY_CODEC_I2S_TX_SDO CYBSP_D3
#define CY_CODEC_I2S_RX_SCK CYBSP_D4
#define CY_CODEC_I2S_RX_WS  CYBSP_D5
#define CY_CODEC_I2S_RX_SDI CYBSP_D6

#endif /* CY8CKIT_028_TFT_CONFIG_H_ */
