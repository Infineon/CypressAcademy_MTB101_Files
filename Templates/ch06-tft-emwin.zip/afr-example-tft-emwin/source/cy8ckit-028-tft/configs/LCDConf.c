/*********************************************************************
*                SEGGER Microcontroller GmbH                         *
*        Solutions for real time microcontroller applications        *
**********************************************************************
*                                                                    *
*        (c) 1996 - 2018  SEGGER Microcontroller GmbH                *
*                                                                    *
*        Internet: www.segger.com    Support:  support@segger.com    *
*                                                                    *
**********************************************************************

** emWin V5.48 - Graphical user interface for embedded applications **
All  Intellectual Property rights  in the Software belongs to  SEGGER.
emWin is protected by  international copyright laws.  Knowledge of the
source code may not be used to write a similar product.  This file may
only be used in accordance with the following terms:

The software  has been licensed to  Cypress Semiconductor Corporation,
whose registered  office is situated  at 198 Champion Ct. San Jose, CA
95134 USA  solely for the  purposes of creating  libraries for Cypress
PSoC3 and  PSoC5 processor-based devices,  sublicensed and distributed
under  the  terms  and  conditions  of  the  Cypress  End User License
Agreement.
Full source code is available at: www.segger.com

We appreciate your understanding and fairness.
----------------------------------------------------------------------
Licensing information
Licensor:                 SEGGER Microcontroller Systems LLC
Licensed to:              Cypress Semiconductor Corp, 198 Champion Ct., San Jose, CA 95134, USA
Licensed SEGGER software: emWin
License number:           GUI-00319
License model:            Services and License Agreement, signed June 10th, 2009
Licensed platform:        Any Cypress platform (Initial targets are: PSoC3, PSoC5)
----------------------------------------------------------------------
Support and Update Agreement (SUA)
SUA period:               2009-06-12 - 2022-07-27
Contact to extend SUA:    sales@segger.com
----------------------------------------------------------------------
File        : LCDConf.c
Purpose     : Generic  configuration file for GUIDRV_FlexColor
---------------------------END-OF-HEADER------------------------------
*/

#include "GUI.h"
#include "GUIDRV_FlexColor.h"

#include "cy_tft.h"
#include "LCDConf.h"
/*********************************************************************
*
*       Layer configuration
*
**********************************************************************
*/
//
//   Color conversion
//   The color conversion functions should be selected according to
//   the color mode of the target display. Details can be found in
//   the chapter "Colors" in the emWin user manual.
//
#define COLOR_CONVERSION GUICC_M565

//
// Display driver
//
#define DISPLAY_DRIVER GUIDRV_FLEXCOLOR

/*********************************************************************
*
*       Configuration checking
*
**********************************************************************
*/
#ifndef   VXSIZE_PHYS
  #define VXSIZE_PHYS XSIZE_PHYS
#endif
#ifndef   VYSIZE_PHYS
  #define VYSIZE_PHYS YSIZE_PHYS
#endif
#ifndef   XSIZE_PHYS
  #error Physical X size of display is not defined!
#endif
#ifndef   YSIZE_PHYS
  #error Physical Y size of display is not defined!
#endif
#ifndef   COLOR_CONVERSION
  #error Color conversion not defined!
#endif
#ifndef   DISPLAY_DRIVER
  #error No display driver defined!
#endif

/********************************************************************
*
*       _InitController
*
* Purpose:
*   Initializes the display controller
*/
static void CY8CKIT_028_TFT_InitController(void)
{
	/* Initialize display interface */
	cy_tft_io_init();

	/* Reset the display controller */
	cy_tft_write_reset_pin(0u);
	Cy_SysLib_Delay(100);
	cy_tft_write_reset_pin(1u);
	Cy_SysLib_Delay(50);

	cy_tft_write_command(0x28);
	cy_tft_write_command(0x11);	/* Exit Sleep mode */
	Cy_SysLib_Delay(100);
	cy_tft_write_command(0x36);
	cy_tft_write_data(0xA0);	/* MADCTL: memory data access control */
	cy_tft_write_command(0x3A);
	cy_tft_write_data(0x65);	/* COLMOD: Interface Pixel format */
	cy_tft_write_command(0xB2);
	cy_tft_write_data(0x0C);
	cy_tft_write_data(0x0C);
	cy_tft_write_data(0x00);
	cy_tft_write_data(0x33);
	cy_tft_write_data(0x33);	/* PORCTRK: Porch setting */
	cy_tft_write_command(0xB7);
	cy_tft_write_data(0x35);	/* GCTRL: Gate Control */
	cy_tft_write_command(0xBB);
	cy_tft_write_data(0x2B);	/* VCOMS: VCOM setting */
	cy_tft_write_command(0xC0);
	cy_tft_write_data(0x2C);	/* LCMCTRL: LCM Control */
	cy_tft_write_command(0xC2);
	cy_tft_write_data(0x01);
	cy_tft_write_data(0xFF);	/* VDVVRHEN: VDV and VRH Command Enable */
	cy_tft_write_command(0xC3);
	cy_tft_write_data(0x11);	/* VRHS: VRH Set */
	cy_tft_write_command(0xC4);
	cy_tft_write_data(0x20);	/* VDVS: VDV Set */
	cy_tft_write_command(0xC6);
	cy_tft_write_data(0x0F);	/* FRCTRL2: Frame Rate control in normal mode */
	cy_tft_write_command(0xD0);
	cy_tft_write_data(0xA4);
	cy_tft_write_data(0xA1);	/* PWCTRL1: Power Control 1 */
	cy_tft_write_command(0xE0);
	cy_tft_write_data(0xD0);
	cy_tft_write_data(0x00);
	cy_tft_write_data(0x05);
	cy_tft_write_data(0x0E);
	cy_tft_write_data(0x15);
	cy_tft_write_data(0x0D);
	cy_tft_write_data(0x37);
	cy_tft_write_data(0x43);
	cy_tft_write_data(0x47);
	cy_tft_write_data(0x09);
	cy_tft_write_data(0x15);
	cy_tft_write_data(0x12);
	cy_tft_write_data(0x16);
	cy_tft_write_data(0x19);	/* PVGAMCTRL: Positive Voltage Gamma control */
	cy_tft_write_command(0xE1);
	cy_tft_write_data(0xD0);
	cy_tft_write_data(0x00);
	cy_tft_write_data(0x05);
	cy_tft_write_data(0x0D);
	cy_tft_write_data(0x0C);
	cy_tft_write_data(0x06);
	cy_tft_write_data(0x2D);
	cy_tft_write_data(0x44);
	cy_tft_write_data(0x40);
	cy_tft_write_data(0x0E);
	cy_tft_write_data(0x1C);
	cy_tft_write_data(0x18);
	cy_tft_write_data(0x16);
	cy_tft_write_data(0x19);	/* NVGAMCTRL: Negative Voltage Gamma control */
	cy_tft_write_command(0x2B);
	cy_tft_write_data(0x00);
	cy_tft_write_data(0x00);
	cy_tft_write_data(0x00);
	cy_tft_write_data(0xEF);	/* Y address set */
	cy_tft_write_command(0x2A);
	cy_tft_write_data(0x00);
	cy_tft_write_data(0x00);
	cy_tft_write_data(0x01);
	cy_tft_write_data(0x3F);	/* X address set */
	Cy_SysLib_Delay(10);
	cy_tft_write_command(0x29);
}

/*********************************************************************
*
*       Public code
*
**********************************************************************
*/
/*********************************************************************
*
*       LCD_X_Config
*
* Function description
*   Called during the initialization process in order to set up the
*   display driver configuration.
*
*/
void LCD_X_Config(void)
{
	GUI_DEVICE * pDevice;
	CONFIG_FLEXCOLOR Config = {0};
	GUI_PORT_API PortAPI = {0};
	//
	// Set the display driver and color conversion
	//
	pDevice = GUI_DEVICE_CreateAndLink(DISPLAY_DRIVER, COLOR_CONVERSION, 0, 0);
	//
	// Display size configuration
	//
	LCD_SetSizeEx (0, XSIZE_PHYS,  YSIZE_PHYS);
	LCD_SetVSizeEx(0, VXSIZE_PHYS, VYSIZE_PHYS);
	//
	// Orientation
	//
	Config.Orientation   = GUI_MIRROR_Y | GUI_SWAP_XY;
	GUIDRV_FlexColor_Config(pDevice, &Config);
	//
	// Set controller and operation mode
	//
	PortAPI.pfWrite8_A0  = cy_tft_write_command;
	PortAPI.pfWrite8_A1  = cy_tft_write_data;
	PortAPI.pfWriteM8_A1 = cy_tft_write_data_stream;
	PortAPI.pfRead8_A1   = cy_tft_read_data;
	PortAPI.pfReadM8_A1  = cy_tft_read_data_stream;

	GUIDRV_FlexColor_SetFunc(pDevice, &PortAPI, GUIDRV_FLEXCOLOR_F66709, GUIDRV_FLEXCOLOR_M16C0B8);
}

/*********************************************************************
*
*       LCD_X_DisplayDriver
*
* Purpose:
*   This function is called by the display driver for several purposes.
*   To support the according task, the routine needs to be adapted to
*   the display controller. Note that the commands marked
*   "optional" are not cogently required and should only be adapted if
*   the display controller supports these features.
*
* Parameter:
*   LayerIndex - Zero based layer index
*   Cmd        - Command to be executed
*   pData      - Pointer to a data structure.
*
* Return Value:
*   < -1 - Error
*     -1 - The command is not handled.
*      0 - OK.
*/
int LCD_X_DisplayDriver(unsigned LayerIndex, unsigned Cmd, void * pData)
{
	int r;

	GUI_USE_PARA(LayerIndex);
	GUI_USE_PARA(pData);

	switch (Cmd)
	{
	case LCD_X_INITCONTROLLER:
		CY8CKIT_028_TFT_InitController();
		r = 0;
		break;

	default:
		r = -1;
		break;
	}

  return r;
}

/*************************** End of file ****************************/
