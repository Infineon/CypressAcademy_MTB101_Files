/******************************************************************************
* File Name: cy_tft_counter.c
*
* Description: The application creates a thread to display and update a counter
* on TFT shield.
*
*******************************************************************************
* (c) 2019, Cypress Semiconductor Corporation. All rights reserved.
*******************************************************************************
* This software, including source code, documentation and related materials
* ("Software"), is owned by Cypress Semiconductor Corporation or one of its
* subsidiaries ("Cypress") and is protected by and subject to worldwide patent
* protection (United States and foreign), United States copyright laws and
* international treaty provisions. Therefore, you may use this Software only
* as provided in the license agreement accompanying the software package from
* which you obtained this Software ("EULA").
*
* If no EULA applies, Cypress hereby grants you a personal, non-exclusive,
* non-transferable license to copy, modify, and compile the Software source
* code solely for use in connection with Cypress's integrated circuit products.
* Any reproduction, modification, translation, compilation, or representation
* of this Software except as specified above is prohibited without the express
* written permission of Cypress.
*
* Disclaimer: THIS SOFTWARE IS PROVIDED AS-IS, WITH NO WARRANTY OF ANY KIND,
* EXPRESS OR IMPLIED, INCLUDING, BUT NOT LIMITED TO, NONINFRINGEMENT, IMPLIED
* WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE. Cypress
* reserves the right to make changes to the Software without notice. Cypress
* does not assume any liability arising out of the application or use of the
* Software or any product or circuit described in the Software. Cypress does
* not authorize its products for use in any products where a malfunction or
* failure of the Cypress product may reasonably be expected to result in
* significant property damage, injury or death ("High Risk Product"). By
* including Cypress's product in a High Risk Product, the manufacturer of such
* system or application assumes all risk of such use and in doing so agrees to
* indemnify Cypress against all liability.
*******************************************************************************/
#include "cycfg.h"
#include "GUI.h"
#include "iot_threads.h"
#include "FreeRTOS.h"
#include "task.h"
#include "semphr.h"
#include "timers.h"
#include "LCDConf.h"

/*******************************************************************************
* Defines
********************************************************************************/
#define TIMER_INTERVAL_MS			(1000)
#define DISPLAY_THREAD_STACK_SIZE	(1024)
#define	DISPLAY_THREAD_PRIORITY		(tskIDLE_PRIORITY + 1)
#define APP_TASK_STACK_SIZE			(1024)
#define	APP_TASK_PRIORITY			(tskIDLE_PRIORITY)

/*******************************************************************************
* Global Variables
********************************************************************************/
SemaphoreHandle_t timerSemaphore;

/*******************************************************************************
* Forward Declaration
********************************************************************************/
int RunApplication(void);

/*******************************************************************************
* Function Name: InitApplication
********************************************************************************
* Summary:
*  Initializes the tasks required to run the application.
*
*******************************************************************************/
void InitApplication(void)
{
    /* Set up the application task */
    Iot_CreateDetachedThread(RunApplication, NULL, APP_TASK_PRIORITY, APP_TASK_STACK_SIZE);
}

/*******************************************************************************
* Function Name: displayThread
********************************************************************************
* Summary:
*  Thread to display counter on TFT shield.
*
* Parameters:
*  arg - Pointer to the argument for the thread passed while thread creation
*
* Return:
*  void
*******************************************************************************/
void displayThread(void* arg)
{
	/* Variable to store count */
	uint32_t count = 0;

	/* Initialize display, emWin internal data structures and variables */
	GUI_Init();

	/* Set font size for the text being displayed */
	GUI_SetFont(&GUI_Font32_1);

	while(1)
	{
		/* Wait for the timer callback to give a semaphore */
		xSemaphoreTake(timerSemaphore, portMAX_DELAY);

		/* Align text to Horizontal and Vertical Center */
		GUI_SetTextAlign(GUI_TA_HCENTER | GUI_TA_VCENTER);

		/* Display the counter value at center of the screen to three decimal places */
		GUI_DispDecAt(count, YSIZE_PHYS/2, XSIZE_PHYS/2, 3);

		/* Increment count value for every timer callback */
		count++;

		/* Reset the counter to 0 if counter exceeds 999 */
		if(count == 1000)
		{
			count = 0;
		}
	}
}

/*******************************************************************************
* Function Name: timer_callback
********************************************************************************
* Summary:
*  Callback function for the timer. Gives a semaphore to unblock Display Thread
*
* Parameters:
*  xTimer - Timer handle
*
* Return:
*  void
*******************************************************************************/
void timer_callback(TimerHandle_t xTimer)
{
	( void )xTimer; /* Suppress compiler warning */
	BaseType_t xHigherPriorityTaskWoken = pdFALSE;

	/* Give a semaphore to unblock Display thread */
	xSemaphoreGiveFromISR(timerSemaphore, &xHigherPriorityTaskWoken);

	/* If xHigherPriorityTaskWoken was set to true you we should yield */
	portYIELD_FROM_ISR( xHigherPriorityTaskWoken );
}

/*******************************************************************************
* Function Name: RunApplication
********************************************************************************
* Summary:
*  Creates a thread to display counter on TFT display.
*
* Parameters:
*  None
*
* Return:
*  int
*******************************************************************************/
int RunApplication(void)
{
	TimerHandle_t seconds_timer;

	/* Create a binary semaphore */
	timerSemaphore = xSemaphoreCreateBinary();

	 /* Create timer to print counter value periodically on TFT shield */
	seconds_timer = xTimerCreate("Timer", TIMER_INTERVAL_MS, true, NULL, timer_callback);

	/* Create display thread */
	xTaskCreate( displayThread, "Display Thread", DISPLAY_THREAD_STACK_SIZE, 0, DISPLAY_THREAD_PRIORITY, 0);

	/* Start timer after thread creation */
	xTimerStart(seconds_timer, 0);
	
	return 0;
}

/* [] END OF FILE */

