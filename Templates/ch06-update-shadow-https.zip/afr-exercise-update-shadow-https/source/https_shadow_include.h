/*
 * cy_http_shadow_demo_include.h
 *
 *  Created on: Dec 12, 2019
 *      Author: smrx
 */

#ifndef DEMOS_CY_HTTPS_SHADOW_CY_HTTP_SHADOW_DEMO_INCLUDE_H_
#define DEMOS_CY_HTTPS_SHADOW_CY_HTTP_SHADOW_DEMO_INCLUDE_H_

/* The config header is always included first. */
#include "iot_config.h"

/* Standard includes. */
#include <stdbool.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

/* Set up logging for this demo. */
#include "iot_demo_logging.h"

/* JSON utilities include. */
#include "iot_json_utils.h"

/* Amazon FreeRTOS includes. */
#include "iot_https_client.h"
#include "iot_https_utils.h"
#include "aws_demo_config.h"
#include "platform/iot_network.h"
#include "private/iot_error.h"
#include "iot_demo_https_common.h"
#include "platform/iot_clock.h"
#include "platform/iot_threads.h"
#include "private/iot_https_internal.h"

#include "cy_pdl.h"
#include "cyhal.h"
#include "cybsp.h"

#include "queue.h"
#include "FreeRTOS.h"

/**
 * @brief Format string representing a Shadow document with a "reported" state.
 *
 * Note the client token, which is required for all Shadow updates. The client
 * token must be unique at any given time, but may be reused once the update is
 * completed. For this demo, a timestamp is used for a client token.
 */
#define SHADOW_REPORTED_JSON    \
    "{"                         \
    "\"state\":{"               \
    "\"reported\":{"            \
    "\"buttonPressCount\":%5d" \
    "}"                         \
    "},"                        \
    "\"clientToken\":\"%06lu\"" \
    "}"

/**
 * @brief The expected size of #SHADOW_REPORTED_JSON.
 *
 * Because all the format specifiers in #SHADOW_REPORTED_JSON include a length,
 * its full size is known at compile-time.
 */
#define EXPECTED_REPORTED_JSON_SIZE    ( sizeof( SHADOW_REPORTED_JSON ) + 2 )

// Push button and LED pin definitions
#define BUTTON_PIN							(P0_4)
#define LED_PIN							    (P13_7)

/* Variable to store button press counts */
int32_t buttonPressCount = 0;

/* Queue details */
#define MESSAGE_SIZE					(sizeof(buttonPressCount))
#define QUEUE_SIZE						(50)
QueueHandle_t msgQueue;

/* Shadow URL for the configured endpoint
 * refer https://docs.aws.amazon.com/iot/latest/developerguide/device-shadow-rest-api.html for details */
#define SHADOW_DEMO_HTTPS_URL "https://" clientcredentialMQTT_BROKER_ENDPOINT "/things/" clientcredentialIOT_THING_NAME "/shadow"

/* TLS port for HTTPS. */
#ifndef IOT_DEMO_HTTPS_PORT
    #define IOT_DEMO_HTTPS_PORT    ( ( uint16_t ) 8443 )
#endif

/* Size in bytes of the User Buffer used to store the internal connection context. The size presented here accounts for
 * storage of the internal connection context. The minimum size can be found in extern const unint32_t connectionUserBufferMinimumSize. */
#ifndef IOT_DEMO_HTTPS_CONN_BUFFER_SIZE
    #define IOT_DEMO_HTTPS_CONN_BUFFER_SIZE    ( 512 )
#endif

/* Size in bytes of the user buffer used to store the internal request context and HTTP request header lines.
 * The size presented here accounts for the storeage of the internal context, the first request line in the HTTP
 * formatted header and extra headers. The minimum size can be found in extern const uint32_t requestUserBufferMinimumSize. */
#ifndef IOT_DEMO_HTTPS_REQ_USER_BUFFER_SIZE
    #define IOT_DEMO_HTTPS_REQ_USER_BUFFER_SIZE    ( 512 )
#endif

/* Size in bytes of the user buffer used to store the internal response context and the HTTP response header lines.
 * The size presented here accounts for the storeage of the internal context, the first request line in the HTTP
 * formatted header and extra headers. The minimum can be found in responseUserBufferMinimumSize.
 * Keep in mind that if the headers from the response do not all fit into this buffer, then the rest of the headers
 * will be discarded. The minimum size can be found in extern const uint32_t responseUserBufferMinimumSize. */
#ifndef IOT_DEMO_HTTPS_RESP_USER_BUFFER_SIZE
    #define IOT_DEMO_HTTPS_RESP_USER_BUFFER_SIZE    ( 1024 )
#endif

/* Size in bytes of the buffer used to store the response body (parts of it). This should be greater than or equal to
 * the size of the file we want to download.*/
#ifndef IOT_DEMO_HTTPS_RESP_BODY_BUFFER_SIZE
    #define IOT_DEMO_HTTPS_RESP_BODY_BUFFER_SIZE    ( 512 )
#endif

/* Time to wait in milliseconds before retrying the HTTPS Connection. A connection is only attempted again if
 * IOT_HTTPS_CONNECTION_ERROR is returned from IotHttpsClient_Connect(). This indicates an error in the network
 * layer. To view logging for network errors update IOT_LOG_LEVEL_NETWORK to IOT_LOG_ERROR in iot_config.h */
#ifndef IOT_DEMO_HTTPS_CONNECTION_RETRY_WAIT_MS
    #define IOT_DEMO_HTTPS_CONNECTION_RETRY_WAIT_MS    ( ( uint32_t ) 3000 )
#endif

/* Number of times to retry the HTTPS connection. A connection is only attempted again if
 * IOT_HTTPS_CONNECTION_ERROR is returned from IotHttpsClient_Connect(). This indicates an error in the network
 * layer. To view logging for network errors update IOT_LOG_LEVEL_NETWORK to IOT_LOG_ERROR in iot_config.h */
#ifndef IOT_DEMO_HTTPS_CONNECTION_NUM_RETRY
    #define IOT_DEMO_HTTPS_CONNECTION_NUM_RETRY    ( ( uint32_t ) 3 )
#endif

/** @endcond */

/*-----------------------------------------------------------*/

/**
 * @brief Buffer used to store the internal connection context.
 */
uint8_t _pConnUserBuffer[ IOT_DEMO_HTTPS_CONN_BUFFER_SIZE ] = { 0 };

/**
 * @brief Buffer used to store the request context and the HTTP request header lines.
 */
uint8_t _pReqUserBuffer[ IOT_DEMO_HTTPS_REQ_USER_BUFFER_SIZE ] = { 0 };

/**
 * @brief Buffer used to store the response context and the HTTP response header lines.
 */
uint8_t _pRespUserBuffer[ IOT_DEMO_HTTPS_RESP_USER_BUFFER_SIZE ] = { 0 };

/**
 * @brief Buffer used to store parts of the response body.
 */
uint8_t _pRespBodyBuffer[ IOT_DEMO_HTTPS_RESP_BODY_BUFFER_SIZE ] = { 0 };

/* A buffer containing the update document. It has static duration to prevent
 * it from being placed on the call stack. */
uint8_t requestStateDoc[ EXPECTED_REPORTED_JSON_SIZE + 1 ] = { 0 };

/* HTTPS Client library return status. */
IotHttpsReturnCode_t httpsClientStatus = IOT_HTTPS_OK;

/* Configurations for the HTTPS connection. */
IotHttpsConnectionInfo_t connConfig = { 0 };
/* Handle identifying the HTTPS connection. */
IotHttpsConnectionHandle_t connHandle = IOT_HTTPS_CONNECTION_HANDLE_INITIALIZER;
/* Configurations for the HTTPS request. */
IotHttpsRequestInfo_t reqConfig = { 0 };
/* Configurations for the HTTPS response. */
IotHttpsResponseInfo_t respConfig = { 0 };

/* Handle identifying the HTTP request. This is valid after the request has been initialized with
    * IotHttpsClient_InitializeRequest(). */
IotHttpsRequestHandle_t reqHandle = IOT_HTTPS_REQUEST_HANDLE_INITIALIZER;

/* Handle identifying the HTTP response. This is valid after the reponse has been received with
    * IotHttpsClient_SendSync(). */
IotHttpsResponseHandle_t respHandle = IOT_HTTPS_RESPONSE_HANDLE_INITIALIZER;
/* Synchronous request specific configurations. */
IotHttpsSyncInfo_t reqSyncInfo = { 0 };
/* Synchronous response specific configurations. */
IotHttpsSyncInfo_t respSyncInfo = { 0 };

/* The location of the path within string SHADOW_DEMO_HTTPS_URL. */
const char * pPath = NULL;
/* The length of the path within string SHADOW_DEMO_HTTPS_URL. */
size_t pathLen = 0;
/* The location of the address within string SHADOW_DEMO_HTTPS_URL. */
const char * pAddress = NULL;
/* The length of the address within string SHADOW_DEMO_HTTPS_URL. */
size_t addressLen = 0;

/* The status of HTTP responses for each request. */
uint16_t respStatus = IOT_HTTPS_STATUS_OK;

/* The body length of HTTP responses for each request. */
uint32_t bodyLength = 0;

/* The current index in the number of connection tries. */
uint32_t connIndex = 0;

#endif /* HTTPS_SHADOW_INCLUDE_H_ */
