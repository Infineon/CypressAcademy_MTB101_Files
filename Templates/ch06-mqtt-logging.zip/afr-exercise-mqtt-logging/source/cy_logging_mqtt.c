/*
 * Amazon FreeRTOS V201908.00
 * Copyright (C) 2019 Amazon.com, Inc. or its affiliates.  All Rights Reserved.
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy of
 * this software and associated documentation files (the "Software"), to deal in
 * the Software without restriction, including without limitation the rights to
 * use, copy, modify, merge, publish, distribute, sublicense, and/or sell copies of
 * the Software, and to permit persons to whom the Software is furnished to do so,
 * subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in all
 * copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, FITNESS
 * FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR
 * COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER
 * IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN
 * CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
 *
 * http://aws.amazon.com/freertos
 * http://www.FreeRTOS.org
 */

/* The config header is always included first. */
#include "iot_config.h"

/* Standard includes. */
#include <stdbool.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include "aws_demo.h" /* For demoContext_t structure declaration */
#include "iot_network_manager_private.h"
#include "iot_init.h"

/* Set up logging for this demo. */
#include "iot_demo_logging.h"

/* Platform layer includes. */
#include "platform/iot_clock.h"
#include "platform/iot_threads.h"

/* MQTT include. */
#include "iot_mqtt.h"
#include "aws_clientcredential.h"


#define MQTT_TIMEOUT_MS                          ( 5000 )

/**
 * @brief The longest client identifier that an MQTT server must accept (as defined
 * by the MQTT 3.1.1 spec) is 23 characters. Add 1 to include the length of the NULL
 * terminator.
 */
#define CLIENT_IDENTIFIER_MAX_LENGTH             ( 24 )

/**
 * @brief The keep-alive interval used for this demo.
 *
 * An MQTT ping request will be sent periodically at this interval.
 */
#define KEEP_ALIVE_SECONDS                       ( 60 )

#define MQTT_LOGGING_TOPIC_PREFIX           "mqttlogging"

/**
 * @brief The Last Will and Testament topic name in this demo.
 *
 * The MQTT server will publish a message to this topic name if this client is
 * unexpectedly disconnected.
 */
#define WILL_TOPIC_NAME                          MQTT_LOGGING_TOPIC_PREFIX "/will"

/**
 * @brief The length of #WILL_TOPIC_NAME.
 */
#define WILL_TOPIC_NAME_LENGTH                   ( ( uint16_t ) ( sizeof( WILL_TOPIC_NAME ) - 1 ) )

/**
 * @brief The message to publish to #WILL_TOPIC_NAME.
 */
#define WILL_MESSAGE                             "Disconnected from the demo."

/**
 * @brief The length of #WILL_MESSAGE.
 */
#define WILL_MESSAGE_LENGTH                      ( ( size_t ) ( sizeof( WILL_MESSAGE ) - 1 ) )

/**
 * @brief The length of each topic filter.
 *
 * For convenience, all topic filters are the same length.
 */
#define TOPIC_FILTER_LENGTH                      ( ( uint16_t ) ( sizeof( MQTT_LOGGING_TOPIC_PREFIX "/topic/1" ) - 1 ) )

/**
 * @brief The maximum number of times each PUBLISH in this demo will be retried.
 */
#define PUBLISH_RETRY_LIMIT                      ( 10 )

/**
 * @brief A PUBLISH message is retried if no response is received within this
 * time.
 */
#define PUBLISH_RETRY_MS                         ( 1000 )

IotMqttError_t connectStatus = IOT_MQTT_STATUS_PENDING;
IotMqttError_t publishStatus = IOT_MQTT_STATUS_PENDING;

/* Handle of the MQTT connection used in this demo. */
IotMqttConnection_t mqttConnection = IOT_MQTT_CONNECTION_INITIALIZER;
IotMqttNetworkInfo_t networkInfo = IOT_MQTT_NETWORK_INFO_INITIALIZER;
IotMqttConnectInfo_t connectInfo = IOT_MQTT_CONNECT_INFO_INITIALIZER;
IotMqttPublishInfo_t willInfo = IOT_MQTT_PUBLISH_INFO_INITIALIZER;

/* Flag to check if MQTT Init and Connect are performed successfully. */
static bool MqttInitDone = false;


/*-----------------------------------------------------------*/
/**
 * @brief The function that performs MQTT Init and MQTT Connect.
 *
 * @param[in] demoConnectedNetwork Variable used to indicate the connected network.
 *
 * @return `EXIT_SUCCESS` if the MQTT init and connect completes successfully; `EXIT_FAILURE` otherwise.
 */
int MqttLoggingInit ( void * pNetworkServerInfo,
                      void * pNetworkCredentialInfo,
                      const IotNetworkInterface_t * pNetworkInterface )
{
    int status = EXIT_SUCCESS;    

	/* Set the members of the network info not set by the initializer. This
	 * struct provided information on the transport layer to the MQTT connection. */
	networkInfo.createNetworkConnection = true;
	networkInfo.u.setup.pNetworkServerInfo = pNetworkServerInfo;
	networkInfo.u.setup.pNetworkCredentialInfo = pNetworkCredentialInfo;
	networkInfo.pNetworkInterface = pNetworkInterface;

	char clientIdentifierBuffer[ CLIENT_IDENTIFIER_MAX_LENGTH ] = clientcredentialIOT_THING_NAME;

	/* Set the members of the connection info not set by the initializer. */
	connectInfo.awsIotMqttMode = true;
	connectInfo.cleanSession = true;
	connectInfo.keepAliveSeconds = KEEP_ALIVE_SECONDS;
	connectInfo.pWillInfo = &willInfo;
	connectInfo.pClientIdentifier = clientIdentifierBuffer;
	connectInfo.clientIdentifierLength = ( uint16_t ) strlen( clientIdentifierBuffer );

	/* Set the members of the Last Will and Testament (LWT) message info. The
	 * MQTT server will publish the LWT message if this client disconnects
	 * unexpectedly. */
	willInfo.pTopicName = WILL_TOPIC_NAME;
	willInfo.topicNameLength = WILL_TOPIC_NAME_LENGTH;
	willInfo.pPayload = WILL_MESSAGE;
	willInfo.payloadLength = WILL_MESSAGE_LENGTH;

	IotMqttError_t mqttInitStatus = IotMqtt_Init();

	if(mqttInitStatus == IOT_MQTT_SUCCESS) 
    {
		connectStatus = IotMqtt_Connect( &networkInfo,
										 &connectInfo,
										 MQTT_TIMEOUT_MS,
										 &mqttConnection );
        if(connectStatus != IOT_MQTT_SUCCESS) 
        {
            printf( "MQTT CONNECT returned error %s.\r\n",
							 IotMqtt_strerror( connectStatus ) );
			status = EXIT_FAILURE;
        }
    }
    else
    {
        printf( "MQTT INIT returned error %s.\r\n",
								 IotMqtt_strerror( mqttInitStatus ) );
		status = EXIT_FAILURE;
    }

    MqttInitDone = (status == EXIT_SUCCESS);
    
    return status;
}

/*-----------------------------------------------------------*/
/**
 * @brief The function that performs MQTT Publish if MQTT Init And Connect was successful; Prints using fputs otherwise.
 *
 */
void MqttLoggingPublish (const char* pPublishPayload)
{
    if (MqttInitDone)
    {
        IotMqttCallbackInfo_t publishComplete = IOT_MQTT_CALLBACK_INFO_INITIALIZER;
        IotMqttPublishInfo_t publishInfo = IOT_MQTT_PUBLISH_INFO_INITIALIZER;
        intptr_t publishCount = 1;

        /* The MQTT library should invoke this callback when a PUBLISH message
            * is successfully transmitted. */
        publishComplete.function = NULL; //_operationCompleteCallback;

        /* Pass the PUBLISH number to the operation complete callback. */
        publishComplete.pCallbackContext = ( void * ) publishCount;

        // char pPublishPayload[] = "Hello world 1!";

        /* Set the common members of the publish info. */
        publishInfo.qos = IOT_MQTT_QOS_1;
        publishInfo.topicNameLength = TOPIC_FILTER_LENGTH;
        publishInfo.pPayload = pPublishPayload;
        publishInfo.payloadLength = strlen(pPublishPayload);
        publishInfo.retryMs = PUBLISH_RETRY_MS;
        publishInfo.retryLimit = PUBLISH_RETRY_LIMIT;
        publishInfo.pTopicName = MQTT_LOGGING_TOPIC_PREFIX "/logs";

        /* PUBLISH a message. This is an asynchronous function that notifies of
            * completion through a callback. */
        publishStatus = IotMqtt_Publish( mqttConnection,
                                            &publishInfo,
                                            0,
                                            &publishComplete,
                                            NULL );

        if( publishStatus != IOT_MQTT_STATUS_PENDING )
        {
            printf( "MQTT PUBLISH %d returned error %s.\r\n",
                            ( int ) publishCount,
                            IotMqtt_strerror( publishStatus ) );
        }
        else
        {
            printf( "\r\nSuccessfully published to '%s' topic:\"%s\"\r\n", publishInfo.pTopicName, pPublishPayload);
        }   
    }
    else
    {
        fputs(pPublishPayload, stdout);
    }
}

/*-----------------------------------------------------------*/
/**
 * @brief The function that performs MQTT Cleanup if MQTT Init And Connect was successful.
 *
 */
void MqttLoggingCleanup ( void )
{
    if (MqttInitDone)
    {
        IotMqtt_Disconnect( mqttConnection, 0 );

        IotMqtt_Cleanup();

        MqttInitDone = false;
    }    
}