#include "FreeRTOS.h"
#include "FreeRTOSConfig.h"
#include "aws_demo_config.h"
#include "task.h"
#include "iot_ble_device_information.h"
#include "iot_ble_data_transfer.h"
#include "iot_ble_config.h"
#include "iot_ble_config_defaults.h"
#include "iot_ble.h"
#include "iot_threads.h"
#include <stdbool.h>
#include "bt_hal_manager_types.h"


/*******************************************************************************
* Macros
********************************************************************************/
#define APP_TASK_STACK_SIZE                 (configMINIMAL_STACK_SIZE * 8)
#define APP_TASK_PRIORITY                   tskIDLE_PRIORITY

const BTUuid_t ADV_UUID1 =
{
    .uu.uu128 = IOT_BLE_ADVERTISING_UUID, //UUID of Device info service
    .ucType   = eBTuuidType128
};


/* User defined Scan response parameters */
IotBleAdvertisementParams_t CustomScanRspParams =
{
    .includeTxPower    = true,
    .name              =
    {
        BTGattAdvNameNone,
        0
    },
    .setScanRsp        = true,
    .appearance        = IOT_BLE_ADVERTISING_APPEARANCE,
    .minInterval       = IOT_BLE_ADVERTISING_CONN_INTERVAL_MIN,
    .maxInterval       = IOT_BLE_ADVERTISING_CONN_INTERVAL_MAX,
    .serviceDataLen    = 0,
    .pServiceData      = NULL,
    .manufacturerLen   = 0,
    .pManufacturerData = NULL,
    .pUUID1            = NULL,
    .pUUID2            = NULL
};

/* NOTE: Adv packet maximum length is 31 bytes. Make sure your adv packet does not exceed this limit */
/* User defined BLE advertisement parameters */
 IotBleAdvertisementParams_t CustomAdvParams =
{
    .includeTxPower    = false,
    .name              = { BTGattAdvNameComplete,          0}, // length of the name for BTGattAdvNameNone and BTGattAdvNameComplete can be ignored as it will not be used.
    .setScanRsp        = false,
    .appearance        = IOT_BLE_ADVERTISING_APPEARANCE,
    .minInterval       = 0,  //min connection interval
    .maxInterval       = 0,  //max connection interval
    .serviceDataLen    = 0,
    .pServiceData      = NULL,
    .manufacturerLen   = 0,
    .pManufacturerData = NULL,
    .pUUID1            = (BTUuid_t*) &ADV_UUID1,
    .pUUID2            = NULL
};

void RunApplication(void * pArgument);

#if ( IOT_BLE_SET_CUSTOM_ADVERTISEMENT_MSG == 1 )
void IotBle_SetCustomAdvCb( IotBleAdvertisementParams_t * pAdvParams,
						   IotBleAdvertisementParams_t * pScanParams )
{
	/* copy the user adv message values to the address provided by callback function */
	pAdvParams->name.ucShortNameLen = CustomAdvParams.name.ucShortNameLen;
	pAdvParams->name.xType          = CustomAdvParams.name.xType;
	pAdvParams->includeTxPower      = CustomAdvParams.includeTxPower;
	pAdvParams->setScanRsp        	= CustomAdvParams.setScanRsp;
	pAdvParams->appearance        	= CustomAdvParams.appearance;
	pAdvParams->minInterval       	= CustomAdvParams.minInterval;
	pAdvParams->maxInterval       	= CustomAdvParams.maxInterval;
	pAdvParams->serviceDataLen    	= CustomAdvParams.serviceDataLen;
	pAdvParams->pServiceData      	= CustomAdvParams.pServiceData;
	pAdvParams->manufacturerLen   	= CustomAdvParams.manufacturerLen;
	pAdvParams->pManufacturerData 	= CustomAdvParams.pManufacturerData;
	pAdvParams->pUUID1            	= CustomAdvParams.pUUID1;
	pAdvParams->pUUID2            	= CustomAdvParams.pUUID2;

	/* copy the scan response values to the address provided by callback function */

	pScanParams->name.ucShortNameLen = CustomScanRspParams.name.ucShortNameLen;
	pScanParams->name.xType 		 = CustomScanRspParams.name.xType;
	pScanParams->includeTxPower    	 = CustomScanRspParams.includeTxPower;
	pScanParams->setScanRsp        	 = CustomScanRspParams.setScanRsp;
	pScanParams->appearance          = CustomScanRspParams.appearance;
	pScanParams->minInterval         = CustomScanRspParams.minInterval;
	pScanParams->maxInterval       	 = CustomScanRspParams.maxInterval;
	pScanParams->serviceDataLen      = CustomScanRspParams.serviceDataLen;
	pScanParams->pServiceData        = CustomScanRspParams.pServiceData;
	pScanParams->manufacturerLen     = CustomScanRspParams.manufacturerLen;
	pScanParams->pManufacturerData   = CustomScanRspParams.pManufacturerData;
	pScanParams->pUUID1              = CustomScanRspParams.pUUID1;
	pScanParams->pUUID2              = CustomScanRspParams.pUUID2;
}
#endif

/*******************************************************************************
* Function Name: InitApplication
********************************************************************************
* Summary:
*  Initializes all the tasks, queues, and other resources required to run the
*  application.
*
*******************************************************************************/
void InitApplication(void)
{
    /* Set up the application task */
    Iot_CreateDetachedThread(RunApplication, NULL, APP_TASK_PRIORITY, APP_TASK_STACK_SIZE);
}

/*******************************************************************************
* Function Name: ApplicationTask
********************************************************************************
* Summary:
*  This function initializes BLE with two services : Device information service
*                                                    Data transfer service
*  It sets the user defined ADV message and starts advertising.
*  Any BLE Central device can be used to scan and connect and use the two services.
*
*  Parameters:
*  pArgument - pointer to the argument to this task.
*
*******************************************************************************/
void RunApplication(void * pArgument)
{
	BTStatus_t status;

    /* \x1b[2J\x1b[;H - ANSI ESC sequence for clear screen */
    printf("\x1b[2J\x1b[;H");

    status = IotBle_Init();
    if(status == eBTStatusSuccess)
    {
    	printf("BLE initialization success and adv started\r\n");
    }

    while(1)
    {

    };
}
