# Amazon FreeRTOS Example: Retarget Output to TFT

This example modifies the configPRINTF to display on the TFT.

## Requirements

- [ModusToolbox™ IDE](https://www.cypress.com/products/modustoolbox-software-environment) v2.0
- [ModusToolbox Amazon FreeRTOS SDK](https://github.com/cypresssemiconductorco/amazon-freertos)
- [Cypress Programmer](https://www.cypress.com/products/psoc-programming-solutions)
- Programming Language: C
- Associated Parts: All [PSoC® 6 MCU](http://www.cypress.com/PSoC6) parts with Amazon FreeRTOS support

## Supported Kits

- [PSoC 6 WiFi-BT Pioneer Kit](https://www.cypress.com/CY8CKIT-062-WiFi-BT) (CY8CKIT-062-WiFi-BT) - Default target
- [CY8CKIT-028-TFT Shield](https://www.cypress.com/documentation/development-kitsboards/tft-display-shield-board-cy8ckit-028-tft)

## Hardware Setup

This example uses the board's default configuration. Refer to the kit user guide to ensure the board is configured correctly.

**Note**: The PSoC 6 WiFi-BT Pioneer Kit ship with KitProg2 installed. ModusToolbox software requires KitProg3. Before using this code example, make sure that the board is upgraded to KitProg3. The tool and instructions are available in the [Firmware Loader](https://github.com/cypresssemiconductorco/Firmware-loader) GitHub repository. If you do not upgrade, you will see an error like "unable to find CMSIS-DAP device" or "KitProg firmware is out of date".

## Software Setup

Install a terminal emulator if you don't have one. Instructions in this document use [Tera Term](https://ttssh2.osdn.jp/index.html.en).

## Using the Example

### First Steps:

1. Clone recursively Amazon FreeRTOS from [GitHub](https://github.com/cypresssemiconductorco/amazon-freertos). 

   ```
   git clone --recurse-submodules https://github.com/cypresssemiconductorco/amazon-freertos.git --branch 201910-MTBAFR1951
   ```

2. Go to the *\<amazon-freertos>/projects/cypress* folder. Download the example and extract it.

   **Note:** *\<amazon-freertos>* refers to the path of the Amazon FreeRTOS folder in your computer. 

3. Open *\<amazon-freertos>/demos/include/aws_clientcredential.h* file and configure the SSID, Wi-Fi password of the desired network, and AWS parameters such as endpoint and Thing name.

4. Configure the client certificate and the private key in *\<amazon-freertos>/demos/include/aws_clientcredential_keys.h* for the Thing used in Step 4.

5. Connect the CY8CKIT-028-TFT shield to the Arduino header.

6. Connect the base kit to your PC using the provided USB cable through the USB connector.

7. Open a terminal program and select the KitProg3 COM port. Set the serial port parameters to 8N1 and 115200 baud.

### Using ModusToolbox IDE:

1. Go to **File** > **Import**.

2. Choose **Existing Projects into Workspace** under **General**, and click **Next**. 

3. Click the **Browse** button near **Select root directory**, choose the CE folder *\<amazon-freertos>/projects/cypress/afr-example-retarget-io-tft*, and click **Finish**. 

4. Right-click on the application project in the Project Explorer. Select **Build Targets** > **Create**.

5. Give `Target name` as **getlibs** and click okay.

6. Expand the application project and double click **Build Targets** > **getlibs**. Wait for the operation to complete.

7. Select the application project, in the **Quick Panel**, scroll down, and click **afr-example-retarget-io-tft Program (KitProg3)**.

## Operation

All configPRINTF messages will now be printed on the TFT screen. The screen will auto scroll to fit new messages.

## Debugging

You can debug the example to step through the code. In the ModusToolbox IDE, use the **afr-example-retarget-io-tft Debug (KitProg3)** configuration in the **Quick Panel**. See [Debugging a PSoC 6 MCU ModusToolbox Project - KBA224621](https://community.cypress.com/docs/DOC-15763) for details.